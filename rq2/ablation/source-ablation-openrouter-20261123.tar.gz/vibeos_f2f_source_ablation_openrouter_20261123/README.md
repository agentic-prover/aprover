# VibeOS RQ2 source-tree ablations via OpenRouter

This directory contains the corrected-input rerun of the three OFAT ablation
arms over the four VibeOS modules used in RQ2.

## Fixed configuration

- BMC-Agent: `f2f31711e`
- VibeOS: `866bfb9`
- CBMC: 5.95.1
- Model: `anthropic/claude-sonnet-4.6`
- Router: OpenRouter
- API path: Anthropic-native `/api/v1/messages`
- Upstream provider: forced to `Anthropic` with no fallback
- Source layout: complete `vibeos/kernel` source tree
- Include roots: `vibeos/kernel`, `vibeos/kernel/libc`
- Per-function CBMC budget: 180 seconds
- Module timeout: 9,000 seconds
- LLM workers: one per module
- Parallel validation: disabled
- Batching: disabled
- Phase-3e triage: disabled

The 12 runs are three arms over four modules. Four modules run concurrently;
the arms are queued. Each run has a separate loopback proxy, a `$40` local
ceiling, and a 2,000-call ceiling.

The completed batch was launched with:

```sh
cd /mnt/disk7/jw_bmc/experiments/vibeos_f2f_source_ablation_openrouter_20261123
OPENROUTER_API_KEY="$OPENROUTER_API_KEY" \
JOBS=4 MAX_CALLS=2000 BUDGET_PER_RUN_USD=40 BASE_PORT=9101 \
bash run_ablation.sh
```

The process was detached with `setsid` because the interactive executor's
lifetime is shorter than a complete wave.

The source files are passed in place rather than copied into isolated run
directories. All four source hashes match the teacher's archived June sources.
Every run must observe 222 public functions from the kernel source tree, return
only `anthropic/claude-sonnet-4.6` responses from the `Anthropic` upstream, and
complete without a local budget denial.

## Arms

- `no_dynamic`: `--no-dynamic-validation`
- `no_realism`: `--no-realism-check`
- `fixed_config`: `--no-bmc-config-agent --no-flag-selection --no-inlining-advisor`

The existing corrected Full `elf` run used direct Anthropic, not OpenRouter.
It is a useful sanity anchor but must not be mixed into a formal OpenRouter
Full-versus-ablation comparison. Full anchors for this matrix still need to be
run through the same OpenRouter path if a contemporaneous matched comparison is
required.

## Completed run

All 12 runs completed with exit code zero. Every run used the complete source
tree, observed 222 public functions, and used the requested model and upstream
provider for every call.

- Calls: 4,310
- Input tokens: 22,706,499
- Output tokens: 2,295,253
- Estimated cost: `$102.54829`
- Overall wall time: approximately 4 h 06 min

The detailed results are in `RESULTS.md`, `metrics.json`,
`final_findings.tsv`, and `validity.tsv`.

To regenerate the machine-readable summaries:

```sh
BMC_RESULTS_ROOT="$PWD" \
BMC_RESULTS_ARMS="no_dynamic no_realism fixed_config" \
BMC_RESULTS_MODEL="anthropic/claude-sonnet-4.6" \
BMC_RESULTS_UPSTREAM_PROVIDER="Anthropic" \
python3 ../vibeos_f2f_ablation_claude_20261122/analyze_results.py
```
