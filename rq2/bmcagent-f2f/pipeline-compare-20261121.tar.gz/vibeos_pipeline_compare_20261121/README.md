# VibeOS pipeline hash comparison

Compare three BMC-Agent source snapshots on the same four VibeOS functions with
one fixed DeepSeek low-reasoning profile:

| label | code |
|---|---|
| `f2f31711e` | June VibeOS sweep source |
| `b9314c7` | September VibeOS ablation source |
| `8c1c50c` | paper-artifacts release source |

The `b9314c7` arm is the completed run under
`../deepseek_low_vibeos_adapt_20261121/runs_min32k`. The comparison runner adds
the other two arms with the same functions, model, proxy, Full switches, Python
environment, VibeOS inputs, and CBMC version.

This is a function-subset comparison. It does not run the 47-function modules.
