# bmc-agent-sec confirmed finding: `malloc`

**Status**: realism-confirmed (any CEx with `realism.verdict == realistic AND confidence != unlikely` makes the function confirmed).
**Generated**: 2026-11-21T21:36:29.969767+00:00

## Target

- **Project**: vibeos_memory
- **Source file**: `memory.c`
- **Function**: `malloc` ((unknown lines))
- **Violated property**: `malloc.overflow.1` (CBMC-reported)
- **Call chain established**: `realloc -> malloc`

## bmc-agent-sec layered verdict

| Layer | Result |
|---|---|
| CBMC | counterexample found at property above |
| Realism (LLM auditor, primary call) | **realistic** / confidence `0.72` |
| Dynamic harness (GCC + signal handlers) | **no_record**, signal=`none` |
| Final tier | `confirmed_system_entry` |

## Realism reasoning

The authoritative malloc body contains `size = (((size) + ((16) - 1)) & ~((16) - 1));` with no overflow guard anywhere between the entry `if (size == 0) return ((void *)0);` and the rounding. For size in [SIZE_MAX-14, SIZE_MAX] the addition wraps to a tiny value and the mask collapses it to 0, so the returned block carries a header size of 0 while the caller believes it obtained a huge buffer. The witness magnitude (2^32-8) is a CBMC 32-bit-model artifact, but the same wrap occurs at 64 bits for any size within 15 of SIZE_MAX, so the bug class is model-independent. Reachability: the verified call graph shows malloc's only callers are calloc and realloc. calloc's body is `size_t total = nmemb * size; void *ptr = malloc(total);` with no multiplication-overflow check, so attacker-chosen nmemb/size (e.g. nmemb=0x1FFFFFFFFFFFFFFF, elem=8) produce total=0xFFFFFFFFFFFFFFF8 verbatim; calloc then zeroes `total` bytes into the zero-size block, an immediate attacker-triggered heap OOB write. That is a genuine, exploitable size-integer-overflow feeding an allocation, exactly the hazard class listed for this allocator. NOTE: the base verdict's claimed upstream vector (ELF p_memsz / FAT32 dirent / FDT totalsize calling malloc directly) is NOT supported by the call graph and should be dropped; the finding remains realistic via the calloc path instead.

## Exploit scenario (LLM-supplied)

Attacker-controlled allocation count crosses into calloc (nmemb/size from a parsed header or syscall), multiplying to a near-SIZE_MAX total; malloc's `size + 15` wraps, `& ~15` yields 0, and the caller receives a zero-sized block while zero-filling/using the full requested length -> out-of-bounds write.

## CBMC counterexample witness

The variable assignments CBMC reports as triggering the violation. Read with the function source below to understand the attack state:

```text
  __CPROVER_dead_object = NULL
  __CPROVER_deallocated = NULL
  __CPROVER_malloc_is_new_array = False
  __CPROVER_max_malloc_size = 8388608u
  __CPROVER_memory_leak = NULL
  __CPROVER_rounding_mode = 0
  alloc_size = sizeof(block_header_t) /*12u*/ 
  dynamic_object.$pad2 = 0
  dynamic_object.is_free = 0
  dynamic_object.next = ((block_header_t *)NULL)
  dynamic_object.size = 0u
  free_list = dynamic_object
  goto_symex$$return_value$$calloc = {'name': 'unknown'}
  heap_end = 0u
  heap_start = 0u
  malloc_res = {'name': 'unknown'}
  malloc_value = {'name': 'unknown'}
  nmemb = 1u
  ram_base = 0u
  ram_size = 0u
  record_malloc = False
  record_may_leak = False
  result = NULL
  return_value___VERIFIER_nondet___CPROVER_bool$1 = False
  return_value___VERIFIER_nondet___CPROVER_bool$2 = False
  return_value_calloc = {'name': 'unknown'}
  return_value_malloc = NULL
  size = 4294967288u
  stat_alloc_count = 0
  stat_free = 0u
  stat_used = 0u
  tmp_overflow_result = <struct: 2 members>
  tmp_overflow_result.overflow-* = False
  tmp_overflow_result.value = sizeof(block_header_t) /*12u*/ 
```

## Function source (from the snapshot)

```c
(source not found on the searched paths; see file_stem above and the committed harness.c)
```

## Per-CEx history

The pipeline ran CBMC multiple times on this function (different failing properties, feedback-loop iterations). Each CEx has its own audit record under `bug_reports/` in the sweep artifact tree:

- `bug_reports/malloc.overflow.1.json`
- `bug_reports/unnamed_1795296856553.json`

## Reproduction

The harness CBMC verified is committed alongside this report as `harness.c`. To re-verify just this finding:

```bash
# Reproduce with CBMC. The self-contained harness is committed alongside this
# report as harness.c (it includes/compiles the source under test). Re-supply
# the SAME -I include dirs and -D defines the original run used.
cbmc \
    --bounds-check --pointer-check --pointer-overflow-check \
    --signed-overflow-check --unwinding-assertions \
    --unwind 8 --timeout 120 \
    --function main \
    malloc/harness.c

```

To re-run the full sweep end-to-end (re-derives this finding from scratch):

```bash
python -m bmc_agent.cli verify-dir --source-dir /mnt/disk7/jw_bmc/experiments/vibeos_pipeline_compare_20261121/runs/8c1c50c/memory/malloc/src --driver vibeos_memory --output <new_output> --exclude 'test_*'  # (re-supply the include/defines/flags you used)
```

## Honest caveats (read before upstream reporting)

- **Dynamic outcome was `no_record`.** WEAK evidence: the dynamic harness did NOT reproduce the crash with the concrete CBMC witness. The realism LLM's vote is the only evidence.
- The realism LLM's attacker scenario may hypothesize an upstream condition (e.g. "some bug elsewhere creates the dangling pointer state"). **Independent code-level verification of that condition is required before reporting upstream.**
- Realism nondeterminism: the same CEx can flip between REALISTIC and UNREALISTIC across runs. Multiple per-CEx records in `bug_reports/` may show different verdicts; this report uses the strongest realistic record by mtime.
- The harness is auto-generated and uses CBMC's nondeterministic-input model. Reading `harness.c` shows exactly what input states CBMC was free to explore — verify those states are actually reachable from the real public API before declaring a vulnerability.
