# bmc-agent-sec confirmed finding: `elf_process_relocations`

**Status**: realism-confirmed (any CEx with `realism.verdict == realistic AND confidence != unlikely` makes the function confirmed).
**Generated**: 2026-11-21T21:16:14.232470+00:00

## Target

- **Project**: vibeos_elf
- **Source file**: `elf.c`
- **Function**: `elf_process_relocations` ((unknown lines))
- **Violated property**: `elf_process_relocations.overflow.1` (CBMC-reported)
- **Call chain established**: `elf_load_at -> elf_process_relocations`

## bmc-agent-sec layered verdict

| Layer | Result |
|---|---|
| CBMC | counterexample found at property above |
| Realism (LLM auditor, primary call) | **realistic** / confidence `medium` |
| Dynamic harness (GCC + signal handlers) | **no_record**, signal=`none` |
| Final tier | `confirmed_system_entry` |

## Realism reasoning

## Evidence gathered

**Function body (authoritative, `lookup_function`):**

```c
uint64_t rela_addr = 0;
uint64_t rela_size = 0;
uint64_t rela_ent = sizeof(Elf64_Rela);
for (const Elf64_Dyn *dyn = dynamic; dyn->d_tag != 0; dyn++) {
    switch (dyn->d_tag) {
        case 7: rela_addr = dyn->d_val; break;
        case 8: rela_size = dyn->d_val; break;
        case 9: rela_ent = dyn->d_val; break;
    }
}
if (rela_addr == 0 || rela_size == 0) { return; }
const Elf64_Rela *rela = (const Elf64_Rela *)(load_base + rela_addr);
int num_relas = rela_size / rela_ent;
```

- All three DT_* values come straight out of the `Elf64_Dyn` array with no validation: `case 8: rela_size = dyn->d_val; break;` and `case 9: rela_ent = dyn->d_val; break;`.
- The only early-exit is `if (rela_addr == 0 || rela_size == 0) { return; }` — it does **not** constrain `rela_ent`, and does not bound `rela_size`.
- The overflow site `int num_relas = rela_size / rela_ent;` narrows a `uint64_t` quotient into a 32-bit `int` with no guard, and `load_base + rela_addr` on the preceding line is unchecked 64-bit addition.

**Call chain (`walk_call_chain`):** `elf_load_at → elf_process_relocations`, caller PRE = `true` (no restrictive precondition). `lookup_function(elf_load_at)` confirms the argument is fully attacker-derived: `dynamic = (const Elf64_Dyn *)(load_base + phdr->p_vaddr);` with `phdr` read from attacker-controlled `ehdr->e_phoff + i * ehdr->e_phentsize`, and the call guarded only by `if (is_pie && dynamic)`. The contents at that address come from `memcpy(dest, src, phdr->p_filesz)` of file bytes — i.e. attacker-chosen `d_val` fields, including a huge DT_RELASZ.

## Assessment of the CEx

The witness state (a `rela_size` large enough that `rela_size / rela_ent` exceeds `INT_MAX`, or `load_base + rela_addr` wraps) is established purely by bytes inside the ELF image the kernel loads. Nothing upstream — not `elf_validate`, not `elf_load_at` — bounds DT_RELASZ or checks DT_RELAENT (`sizeof(Elf64_Rela

## Exploit scenario (LLM-supplied)

(none)

## CBMC counterexample witness

The variable assignments CBMC reports as triggering the violation. Read with the function source below to understand the attack state:

```text
  __CPROVER_dead_object = NULL
  __CPROVER_deallocated = NULL
  __CPROVER_max_malloc_size = 8388608u
  __CPROVER_memory_leak = NULL
  __CPROVER_rounding_mode = 0
  _dynamic_obj = <struct: 2 members>
  dyn = {'name': 'unknown'}
  dynamic = _dynamic_obj!0@1
  load_base = 4185915621u
  rela = ((const Elf64_Rela *)NULL)
  rela_addr = 134217744u
  rela_ent = 0u
  rela_size = 2097152u
```

## Function source (from the snapshot)

```c
(source not found on the searched paths; see file_stem above and the committed harness.c)
```

## Per-CEx history

The pipeline ran CBMC multiple times on this function (different failing properties, feedback-loop iterations). Each CEx has its own audit record under `bug_reports/` in the sweep artifact tree:

- `bug_reports/elf_process_relocations.overflow.1.json`
- `bug_reports/elf_process_relocations.pointer_arithmetic.5.json`
- `bug_reports/elf_process_relocations.pointer_dereference.5.json`
- `bug_reports/unnamed_1795294875673.json`

## Reproduction

The harness CBMC verified is committed alongside this report as `harness.c`. To re-verify just this finding:

```bash
# Reproduce with CBMC. The self-contained harness is committed alongside this
# report as harness.c (it includes/compiles the source under test). Re-supply
# the SAME -I include dirs and -D defines the original run used.
cbmc \
    --bounds-check --pointer-check --pointer-overflow-check \
    --signed-overflow-check --unwinding-assertions \
    --unwind 8 --timeout 120 \
    --function main \
    elf_process_relocations/harness.c

```

To re-run the full sweep end-to-end (re-derives this finding from scratch):

```bash
python -m bmc_agent.cli verify-dir --source-dir /mnt/disk7/jw_bmc/experiments/vibeos_pipeline_compare_20261121/runs/8c1c50c/elf/elf_process_relocations/src --driver vibeos_elf --output <new_output> --exclude 'test_*'  # (re-supply the include/defines/flags you used)
```

## Honest caveats (read before upstream reporting)

- **Dynamic outcome was `no_record`.** WEAK evidence: the dynamic harness did NOT reproduce the crash with the concrete CBMC witness. The realism LLM's vote is the only evidence.
- The realism LLM's attacker scenario may hypothesize an upstream condition (e.g. "some bug elsewhere creates the dangling pointer state"). **Independent code-level verification of that condition is required before reporting upstream.**
- Realism nondeterminism: the same CEx can flip between REALISTIC and UNREALISTIC across runs. Multiple per-CEx records in `bug_reports/` may show different verdicts; this report uses the strongest realistic record by mtime.
- The harness is auto-generated and uses CBMC's nondeterministic-input model. Reading `harness.c` shows exactly what input states CBMC was free to explore — verify those states are actually reachable from the real public API before declaring a vulnerability.
