# bmc-agent-sec confirmed finding: `fb_draw_char`

**Status**: realism-confirmed (any CEx with `realism.verdict == realistic AND confidence != unlikely` makes the function confirmed).
**Generated**: 2026-11-21T21:33:42.551751+00:00

## Target

- **Project**: vibeos_fb
- **Source file**: `fb.c`
- **Function**: `fb_draw_char` ((unknown lines))
- **Violated property**: `fb_draw_char.overflow.1` (CBMC-reported)
- **Call chain established**: `fb_draw_string -> fb_draw_char`

## bmc-agent-sec layered verdict

| Layer | Result |
|---|---|
| CBMC | counterexample found at property above |
| Realism (LLM auditor, primary call) | **realistic** / confidence `0.65` |
| Dynamic harness (GCC + signal handlers) | **no_record**, signal=`none` |
| Final tier | `confirmed_system_entry` |

## Realism reasoning

lookup_function(fb_draw_char) confirms the sole bounds check is `if (x + 8 > fb_width || y + 16 > fb_buffer_height) return;`, which performs the same unsigned addition it is trying to validate. There is no wrap-safe form (no `x > fb_width - 8`, no `x + 8 < x`, no overflow builtin). The very next line is `uint32_t *row_ptr = &fb_base[y * fb_width + x];`, taken with no further validation, and it is dereferenced/written 8 times per row for 16 rows. With x = 0xFFFFFFF8 and fb_width = 0 (pre-init default), x+8 wraps to 0 so `0 > 0` is false, the early return is skipped and row_ptr = &fb_base[0xFFFFFFF8] — a wild pointer written 128 times (row_ptr += fb_width = +=0). With a live framebuffer and fb_width >= 4, x = 0xFFFFFFFC (x+8 == 4) also passes and y*fb_width + x lands far outside the glyph cell for small y. The reachability link is verified: walk_call_chain shows fb_draw_string as fb_draw_char's caller with pre `true`, and lookup_function(fb_draw_string) shows `x += 8` in a loop over the string with no per-call re-validation of x against fb_width, so the coordinate passed down is not bounded by anything the caller establishes. y + 16 and y * fb_width carry the same wrap defect, so the CEx is not dependent on a single contrived value. This is a true out-of-bounds-write via integer wrap, not a hardening-only or harness artifact.

## Exploit scenario (LLM-supplied)

The weakest link is the initial coordinate: fb_draw_string has no in-corpus callers, so the 'attacker supplies x' step is justified by API contract (exported primitive, caller pre = true, console/trap coordinates treated as unbounded per the trust note) rather than by a verified call edge. Reaching x >= 0xFFFFFFF8 purely via `x += 8` accumulation instead would need ~536M characters (~512 MB string), so the realistic trigger is an unbounded initial x, not string length. Also, the base verdict's appeal to an 'explicit early-boot caveat' in the trust note is unsupported — the note has no such text — but the defect stands regardless of fb_base/fb_width values.

## CBMC counterexample witness

The variable assignments CBMC reports as triggering the violation. Read with the function source below to understand the attack state:

```text
  __CPROVER_dead_object = NULL
  __CPROVER_deallocated = NULL
  __CPROVER_max_malloc_size = 8388608u
  __CPROVER_memory_leak = NULL
  __CPROVER_rounding_mode = 0
  bg = 0u
  c = 127
  fb_base = ((__CPROVER_size_t *)NULL)
  fb_buffer_height = 0u
  fb_height = 0u
  fb_pitch = 0u
  fb_width = 0u
  fg = 0u
  font_data = <array: 256 elements>
  x = 4294967288u
  y = 4294967280u
```

## Function source (from the snapshot)

```c
(source not found on the searched paths; see file_stem above and the committed harness.c)
```

## Per-CEx history

The pipeline ran CBMC multiple times on this function (different failing properties, feedback-loop iterations). Each CEx has its own audit record under `bug_reports/` in the sweep artifact tree:

- `bug_reports/fb_draw_char.overflow.1.json`
- `bug_reports/fb_draw_char.pointer_arithmetic.1.json`
- `bug_reports/fb_draw_char.pointer_arithmetic.3.json`
- `bug_reports/fb_draw_char.pointer_arithmetic.4.json`
- `bug_reports/fb_draw_char.pointer_dereference.7.json`
- `bug_reports/unnamed_1795295861967.json`
- `bug_reports/unnamed_1795296272933.json`
- `bug_reports/unnamed_1795296478799.json`
- `bug_reports/unnamed_1795296656010.json`

## Reproduction

The harness CBMC verified is committed alongside this report as `harness.c`. To re-verify just this finding:

```bash
# Reproduce with CBMC. The self-contained harness is committed alongside this
# report as harness.c (it includes/compiles the source under test). Re-supply
# the SAME -I include dirs and -D defines the original run used.
cbmc \
    --bounds-check --pointer-check --pointer-overflow-check \
    --signed-overflow-check --unwinding-assertions \
    --unwind 8 --timeout 120 \
    --function main \
    fb_draw_char/harness.c

```

To re-run the full sweep end-to-end (re-derives this finding from scratch):

```bash
python -m bmc_agent.cli verify-dir --source-dir /mnt/disk7/jw_bmc/experiments/vibeos_pipeline_compare_20261121/runs/8c1c50c/fb/fb_draw_char/src --driver vibeos_fb --output <new_output> --exclude 'test_*'  # (re-supply the include/defines/flags you used)
```

## Honest caveats (read before upstream reporting)

- **Dynamic outcome was `no_record`.** WEAK evidence: the dynamic harness did NOT reproduce the crash with the concrete CBMC witness. The realism LLM's vote is the only evidence.
- The realism LLM's attacker scenario may hypothesize an upstream condition (e.g. "some bug elsewhere creates the dangling pointer state"). **Independent code-level verification of that condition is required before reporting upstream.**
- Realism nondeterminism: the same CEx can flip between REALISTIC and UNREALISTIC across runs. Multiple per-CEx records in `bug_reports/` may show different verdicts; this report uses the strongest realistic record by mtime.
- The harness is auto-generated and uses CBMC's nondeterministic-input model. Reading `harness.c` shows exactly what input states CBMC was free to explore — verify those states are actually reachable from the real public API before declaring a vulnerability.
