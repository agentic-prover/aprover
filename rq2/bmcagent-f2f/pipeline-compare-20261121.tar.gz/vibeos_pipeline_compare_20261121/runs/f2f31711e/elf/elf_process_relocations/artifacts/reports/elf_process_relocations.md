# bmc-agent-sec confirmed finding: `elf_process_relocations`

**Status**: realism-confirmed (any CEx with `realism.verdict == realistic AND confidence != unlikely` makes the function confirmed).
**Generated**: 2026-11-21T20:11:56.799113+00:00

## Target

- **Project**: vibeos_elf
- **Source file**: `elf.c`
- **Function**: `elf_process_relocations` ((unknown lines))
- **Violated property**: `elf_process_relocations.overflow.1` (CBMC-reported)
- **Call chain established**: `elf_load_at -> elf_process_relocations`

## bmc-agent-sec layered verdict

| Layer | Result |
|---|---|
| CBMC | counterexample found at property above |
| Realism (LLM auditor, primary call) | **realistic** / confidence `medium` |
| Dynamic harness (GCC + signal handlers) | **no_record**, signal=`none` |
| Final tier | `confirmed_system_entry` |

## Realism reasoning

## Evidence

**Function body (authoritative, from `lookup_function`):**
```c
uint64_t rela_ent = sizeof(Elf64_Rela);
for (const Elf64_Dyn *dyn = dynamic; dyn->d_tag != 0; dyn++) {
    switch (dyn->d_tag) {
        case 7: rela_addr = dyn->d_val; break;
        case 8: rela_size = dyn->d_val; break;
        case 9: rela_ent  = dyn->d_val; break;
    }
}
if (rela_addr == 0 || rela_size == 0) { return; }
const Elf64_Rela *rela = (const Elf64_Rela *)(load_base + rela_addr);
int num_relas = rela_size / rela_ent;
```

**Guard search (a)/(b)/(c):**
- Quoted line: `const Elf64_Rela *rela = (const Elf64_Rela *)(load_base + rela_addr);` — pure addition of two attacker-chosen `uint64_t`s, no check.
- 3 lines above: `if (rela_addr == 0 || rela_size == 0) { return; }` — this only rejects zero; it does **not** constrain `rela_addr` against `load_base` wraparound, and it does **not** check `rela_ent` at all.
- `rela_ent` is taken verbatim from `DT_RELAENT` (`case 9: rela_ent = dyn->d_val;`), so `rela_size / rela_ent` is an attacker-controlled division with **no zero check** (div-by-zero trap = kernel panic on bare metal), and `num_relas` is a `uint64_t` quotient truncated into `int` (overflow/negative-index class).
- Inside the loop, `uint64_t *target = (uint64_t *)(load_base + offset); *target = load_base + addend;` performs a write to an attacker-directed address with no bounds check.

**Call chain:** `elf_process_relocations` ← `elf_load_at` with caller PRE `true`. `elf_load_at` reads `phdr->p_vaddr`, `e_type`, `e_phnum`, `e_phoff` straight from attacker image bytes and passes `dynamic = load_base + phdr->p_vaddr` without any structural check; `elf_validate` runs first but the CEx state (is_pie, PT_DYNAMIC present, DT_RELA/DT_RELASZ/DT_RELAENT values) is fully attacker-settable within any plausibly-validated header. Per the trust boundary, loaded ELF image bytes are explicitly attacker-controlled, and no precondition may be added to bound them — adding one would mask exactly th

## Exploit scenario (LLM-supplied)

(none)

## CBMC counterexample witness

The variable assignments CBMC reports as triggering the violation. Read with the function source below to understand the attack state:

```text
  __CPROVER_dead_object = NULL
  __CPROVER_deallocated = NULL
  __CPROVER_max_malloc_size = 36028797018963968ul
  __CPROVER_memory_leak = NULL
  __CPROVER_rounding_mode = 0
  _dynamic_obj = <struct: 2 members>
  dyn = {'name': 'unknown'}
  dynamic = _dynamic_obj!0@1
  load_base = 9223372036854775808ul
  rela = ((const Elf64_Rela *)NULL)
  rela_addr = 9223372036854783944ul
  rela_ent = 2814749767106575ul
  rela_size = 22517998136852608ul
```

## Function source (from the snapshot)

```c
(source not found on the searched paths; see file_stem above and the committed harness.c)
```

## Per-CEx history

The pipeline ran CBMC multiple times on this function (different failing properties, feedback-loop iterations). Each CEx has its own audit record under `bug_reports/` in the sweep artifact tree:

- `bug_reports/elf_process_relocations.overflow.1.json`
- `bug_reports/elf_process_relocations.pointer_arithmetic.5.json`
- `bug_reports/elf_process_relocations.pointer_dereference.5.json`
- `bug_reports/unnamed_1795291088818.json`

## Reproduction

The harness CBMC verified is committed alongside this report as `harness.c`. To re-verify just this finding:

```bash
# Reproduce with CBMC. The self-contained harness is committed alongside this
# report as harness.c (it includes/compiles the source under test). Re-supply
# the SAME -I include dirs and -D defines the original run used.
cbmc \
    --bounds-check --pointer-check --pointer-overflow-check \
    --signed-overflow-check --unwinding-assertions \
    --unwind 8 --timeout 120 \
    --function main \
    elf_process_relocations/harness.c

```

To re-run the full sweep end-to-end (re-derives this finding from scratch):

```bash
python -m bmc_agent.cli verify-dir --source-dir /mnt/disk7/jw_bmc/experiments/vibeos_pipeline_compare_20261121/runs/f2f31711e/elf/elf_process_relocations/src --driver vibeos_elf --output <new_output> --exclude 'test_*'  # (re-supply the include/defines/flags you used)
```

## Honest caveats (read before upstream reporting)

- **Dynamic outcome was `no_record`.** WEAK evidence: the dynamic harness did NOT reproduce the crash with the concrete CBMC witness. The realism LLM's vote is the only evidence.
- The realism LLM's attacker scenario may hypothesize an upstream condition (e.g. "some bug elsewhere creates the dangling pointer state"). **Independent code-level verification of that condition is required before reporting upstream.**
- Realism nondeterminism: the same CEx can flip between REALISTIC and UNREALISTIC across runs. Multiple per-CEx records in `bug_reports/` may show different verdicts; this report uses the strongest realistic record by mtime.
- The harness is auto-generated and uses CBMC's nondeterministic-input model. Reading `harness.c` shows exactly what input states CBMC was free to explore — verify those states are actually reachable from the real public API before declaring a vulnerability.
