# bmc-agent-sec confirmed finding: `malloc`

**Status**: realism-confirmed (any CEx with `realism.verdict == realistic AND confidence != unlikely` makes the function confirmed).
**Generated**: 2026-11-21T20:56:20.038429+00:00

## Target

- **Project**: vibeos_memory
- **Source file**: `memory.c`
- **Function**: `malloc` ((unknown lines))
- **Violated property**: `malloc.pointer_arithmetic.2` (CBMC-reported)
- **Call chain established**: `calloc -> malloc`

## bmc-agent-sec layered verdict

| Layer | Result |
|---|---|
| CBMC | counterexample found at property above |
| Realism (LLM auditor, primary call) | **realistic** / confidence `medium` |
| Dynamic harness (GCC + signal handlers) | **no_record**, signal=`none` |
| Final tier | `confirmed_system_entry` |

## Realism reasoning

## Reconsidering

Reading the authoritative body:

```c
size = (((size) + ((16) - 1)) & ~((16) - 1));
...
if (current->is_free && current->size >= size) {
    size_t old_size = current->size;
    if (current->size >= size + sizeof(block_header_t) + 16) {
        block_header_t *new_block = (block_header_t *)((uint8_t *)current + sizeof(block_header_t) + size);
```

The base verdict's central claim — "to overflow you need `size` ~1e19, and the outer guard then requires a free block of size ~1.38e19" — **misses that the outer guard is itself computed in wrapping 64-bit unsigned arithmetic**.

- Attacker/partner input `size = 0xFFFFFFFFFFFFFFF0` (= 2⁶⁴−16) passes the `size == 0` test.
- The alignment round-up `(((size) + ((16) - 1)) & ~((16) - 1))` does *not* overflow here: `(2⁶⁴−16) + 15 = 2⁶⁴−1`, `& ~15` → `2⁶⁴−16`. So the rounded size stays huge (values in `[2⁶⁴−31, 2⁶⁴−16]` all round to `2⁶⁴−16`).
- Guard: `current->size >= size + sizeof(block_header_t) + 16` = `current->size >= (2⁶⁴−16) + 32` = `current->size >= 16` **after wraparound**. A 16-byte free block suffices — *not* 1.38e19 bytes.
- Then `(uint8_t *)current + sizeof(block_header_t) + size` = `current + 16 + (2⁶⁴−16)` = `current + 2⁶⁴` ≡ `current` — the very pointer-arithmetic wraparound CBMC flags.
- Consequence: `new_block == current`, `current->size = 2⁶⁴−16`, `current->next = new_block = current` → free list becomes a self-cycle; the next traversal (`current = current->next`) never terminates → kernel DoS. Later carves also trust the bogus 2⁶⁴−16 size.

`memory_init` sets `free_list->size = heap_end - heap_start - sizeof(block_header_t)` with `heap_max` capped at `0x5F000000 - 1MB - 64MB` (~1.4e9), so a real free block of ≥16 bytes always exists; `current->is_free` is 1 for the pristine free list. The call graph (`calloc`, `realloc` → `malloc`, both `caller_pre: true`) plus attacker-derived ELF/disk/DTB lengths means such a `size` is fully reachable. `memory_init`'s real heap *helps* the CEx (any block

## Exploit scenario (LLM-supplied)

(none)

## CBMC counterexample witness

The variable assignments CBMC reports as triggering the violation. Read with the function source below to understand the attack state:

```text
  __CPROVER_dead_object = NULL
  __CPROVER_deallocated = NULL
  __CPROVER_max_malloc_size = 36028797018963968ul
  __CPROVER_memory_leak = NULL
  __CPROVER_rounding_mode = 0
  _r = {'name': 'unknown'}
  current = {'name': 'pointer', 'type': 'block_header_t *'}
  free_list = {'name': 'unknown'}
  goto_symex$$return_value$$calloc = {'name': 'unknown'}
  heap_end = 0ul
  heap_start = 0ul
  new_block = ((block_header_t *)NULL)
  nmemb = 1ul
  old_size = 13801492473613649924ul
  ram_base = 0ul
  ram_size = 0ul
  result = NULL
  return_value_calloc = {'name': 'unknown'}
  return_value_malloc = NULL
  size = 13657166179247063040ul
  stat_alloc_count = 0
  stat_free = 0ul
  stat_used = 0ul
```

## Function source (from the snapshot)

```c
(source not found on the searched paths; see file_stem above and the committed harness.c)
```

## Per-CEx history

The pipeline ran CBMC multiple times on this function (different failing properties, feedback-loop iterations). Each CEx has its own audit record under `bug_reports/` in the sweep artifact tree:

- `bug_reports/malloc.overflow.1.json`
- `bug_reports/malloc.pointer_arithmetic.1.json`
- `bug_reports/malloc.pointer_arithmetic.2.json`
- `bug_reports/malloc.pointer_dereference.1.json`
- `bug_reports/malloc.pointer_dereference.2.json`
- `bug_reports/malloc.pointer_dereference.3.json`
- `bug_reports/unnamed_1795292851957.json`
- `bug_reports/unnamed_1795293107819.json`
- `bug_reports/unnamed_1795293445854.json`
- `bug_reports/unnamed_1795294191943.json`

## Reproduction

The harness CBMC verified is committed alongside this report as `harness.c`. To re-verify just this finding:

```bash
# Reproduce with CBMC. The self-contained harness is committed alongside this
# report as harness.c (it includes/compiles the source under test). Re-supply
# the SAME -I include dirs and -D defines the original run used.
cbmc \
    --bounds-check --pointer-check --pointer-overflow-check \
    --signed-overflow-check --unwinding-assertions \
    --unwind 8 --timeout 120 \
    --function main \
    malloc/harness.c

```

To re-run the full sweep end-to-end (re-derives this finding from scratch):

```bash
python -m bmc_agent.cli verify-dir --source-dir /mnt/disk7/jw_bmc/experiments/vibeos_pipeline_compare_20261121/runs/f2f31711e/memory/malloc/src --driver vibeos_memory --output <new_output> --exclude 'test_*'  # (re-supply the include/defines/flags you used)
```

## Honest caveats (read before upstream reporting)

- **Dynamic outcome was `no_record`.** WEAK evidence: the dynamic harness did NOT reproduce the crash with the concrete CBMC witness. The realism LLM's vote is the only evidence.
- The realism LLM's attacker scenario may hypothesize an upstream condition (e.g. "some bug elsewhere creates the dangling pointer state"). **Independent code-level verification of that condition is required before reporting upstream.**
- Realism nondeterminism: the same CEx can flip between REALISTIC and UNREALISTIC across runs. Multiple per-CEx records in `bug_reports/` may show different verdicts; this report uses the strongest realistic record by mtime.
- The harness is auto-generated and uses CBMC's nondeterministic-input model. Reading `harness.c` shows exactly what input states CBMC was free to explore — verify those states are actually reachable from the real public API before declaring a vulnerability.
