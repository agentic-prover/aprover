# bmc-agent-sec confirmed finding: `fb_draw_char`

**Status**: realism-confirmed (any CEx with `realism.verdict == realistic AND confidence != unlikely` makes the function confirmed).
**Generated**: 2026-11-21T20:26:42.281735+00:00

## Target

- **Project**: vibeos_fb
- **Source file**: `fb.c`
- **Function**: `fb_draw_char` ((unknown lines))
- **Violated property**: `fb_draw_char.pointer_dereference.9` (CBMC-reported)
- **Call chain established**: `fb_draw_string -> fb_draw_char`

## bmc-agent-sec layered verdict

| Layer | Result |
|---|---|
| CBMC | counterexample found at property above |
| Realism (LLM auditor, primary call) | **realistic** / confidence `0.9` |
| Dynamic harness (GCC + signal handlers) | **no_record**, signal=`none` |
| Final tier | `confirmed_system_entry` |

## Realism reasoning

fb_draw_char's clipping guard uses wrapping unsigned arithmetic: 'if (x + 8 > fb_width || y + 16 > fb_buffer_height) return;'. With attacker-controlled x=0xFFFFFFF8 (or y=0xFFFFFFF0), x+8 / y+16 wrap to 0, so neither overflow comparison is true and the guard does not return. The code then computes 'uint32_t *row_ptr = &fb_base[y * fb_width + x];' where y*fb_width can overflow uint32_t with no re-validation, yielding an out-of-bounds pointer that receives 16 rows of 8 uint32_t writes. This is a real integer-overflow-to-OOB-write, reachable: fb_draw_string calls fb_draw_char(x, y, *s, fg, bg) passing its own x/y parameters unmodified, and these coordinates are attacker-controlled per the target spec.

## Exploit scenario (LLM-supplied)

The unsigned clipping check x+8>fb_width / y+16>fb_buffer_height wraps for large coordinates, and the subsequent fb_base[y*fb_width + x] index computation overflows with no bound re-check, giving an OOB write reachable via fb_draw_string with attacker-supplied x/y.

## CBMC counterexample witness

The variable assignments CBMC reports as triggering the violation. Read with the function source below to understand the attack state:

```text
  __CPROVER_dead_object = NULL
  __CPROVER_deallocated = NULL
  __CPROVER_max_malloc_size = 36028797018963968ul
  __CPROVER_memory_leak = NULL
  __CPROVER_rounding_mode = 0
  bg = 0u
  bits = 16
  c = 127
  fb_base = ((uint32_t *)NULL)
  fb_buffer_height = 0u
  fb_height = 0u
  fb_pitch = 0u
  fb_width = 0u
  fg = 0u
  font_data = <array: 256 elements>
  glyph = {'name': 'unknown'}
  row = 0
  row_ptr = {'name': 'unknown'}
  x = 4294967288u
  y = 4294967280u
```

## Function source (from the snapshot)

```c
(source not found on the searched paths; see file_stem above and the committed harness.c)
```

## Per-CEx history

The pipeline ran CBMC multiple times on this function (different failing properties, feedback-loop iterations). Each CEx has its own audit record under `bug_reports/` in the sweep artifact tree:

- `bug_reports/fb_draw_char.overflow.1.json`
- `bug_reports/fb_draw_char.overflow.2.json`
- `bug_reports/fb_draw_char.pointer_arithmetic.1.json`
- `bug_reports/fb_draw_char.pointer_dereference.7.json`
- `bug_reports/fb_draw_char.pointer_dereference.9.json`
- `bug_reports/unnamed_1795291999187.json`
- `bug_reports/unnamed_1795292213549.json`
- `bug_reports/unnamed_1795292397670.json`
- `bug_reports/unnamed_1795292588230.json`

## Reproduction

The harness CBMC verified is committed alongside this report as `harness.c`. To re-verify just this finding:

```bash
# Reproduce with CBMC. The self-contained harness is committed alongside this
# report as harness.c (it includes/compiles the source under test). Re-supply
# the SAME -I include dirs and -D defines the original run used.
cbmc \
    --bounds-check --pointer-check --pointer-overflow-check \
    --signed-overflow-check --unwinding-assertions \
    --unwind 8 --timeout 120 \
    --function main \
    fb_draw_char/harness.c

```

To re-run the full sweep end-to-end (re-derives this finding from scratch):

```bash
python -m bmc_agent.cli verify-dir --source-dir /mnt/disk7/jw_bmc/experiments/vibeos_pipeline_compare_20261121/runs/f2f31711e/fb/fb_draw_char/src --driver vibeos_fb --output <new_output> --exclude 'test_*'  # (re-supply the include/defines/flags you used)
```

## Honest caveats (read before upstream reporting)

- **Dynamic outcome was `no_record`.** WEAK evidence: the dynamic harness did NOT reproduce the crash with the concrete CBMC witness. The realism LLM's vote is the only evidence.
- The realism LLM's attacker scenario may hypothesize an upstream condition (e.g. "some bug elsewhere creates the dangling pointer state"). **Independent code-level verification of that condition is required before reporting upstream.**
- Realism nondeterminism: the same CEx can flip between REALISTIC and UNREALISTIC across runs. Multiple per-CEx records in `bug_reports/` may show different verdicts; this report uses the strongest realistic record by mtime.
- The harness is auto-generated and uses CBMC's nondeterministic-input model. Reading `harness.c` shows exactly what input states CBMC was free to explore — verify those states are actually reachable from the real public API before declaring a vulnerability.
