# bmc-agent-sec confirmed findings

**Generated**: 2026-11-21T20:26:42.284068+00:00  
**Sweep output**: `/mnt/disk7/jw_bmc/experiments/vibeos_pipeline_compare_20261121/runs/f2f31711e/fb/fb_draw_char/artifacts`  
**Driver**: `vibeos_fb`

## Summary (1 realism-endorsed function(s))

A function is counted as confirmed if AT LEAST ONE of its CBMC counterexamples passed the realism check (verdict=realistic, confidence!=unlikely). Realism nondeterminism is real: see each report's per-CEx history for the audit trail.

| # | Function | File | Property | Tier | Realism | Dynamic |
|---|---|---|---|---|---|---|
| 1 | [`fb_draw_char`](fb_draw_char.md) | `fb.c` | `fb_draw_char.pointer_dereference.9` | `confirmed_system_entry` | realistic / 0.9 | no_record |

## Evidence breakdown

How strong is the runtime evidence behind each finding?

| Dynamic outcome | Count | What it means |
|---|---|---|
| `confirmed` | 0 | GCC+ASAN harness actually crashed at runtime — PoC-grade evidence |
| `not_triggered` | 0 | Harness compiled and ran clean; the specific CBMC witness didn't reproduce. Bug may still be real with different inputs. |
| `inconclusive` | 0 | Harness compile failed (e.g. private headers); no runtime signal either way. |
| `no_record` / `skipped` | 1 | Dynamic didn't run (disabled, or both static checks errored). |

## Per-finding scenarios

**1. [`fb_draw_char`](fb_draw_char.md)** — `fb.c`

> The unsigned clipping check x+8>fb_width / y+16>fb_buffer_height wraps for large coordinates, and the subsequent fb_base[y*fb_width + x] index computation overflows with no bound re-check, giving an O

## How to read these findings

1. The **realism check** is the audit. bmc-agent-sec counts a finding as a real bug when the LLM auditor (given full code context, callers, dynamic outcome) votes REALISTIC. The same LLM that finds bugs is told to be its own skeptic.
2. The **dynamic outcome** column tells you whether the GCC+ASAN runtime check independently confirmed the crash. `confirmed` is the strongest evidence; `not_triggered` is the most ambiguous (could be a real bug with a different attacker input, could be an FP).
3. The **tier** column is the pipeline's classification: `confirmed_dynamic` > `confirmed_system_entry` > `confirmed_bmc`. The tier guard ensures `confirmed_dynamic` is only assigned when dynamic actually crashed.
4. Open the per-finding `<function>.md` for: full realism reasoning, attacker scenario, CBMC counterexample witness, function source, and concrete `cbmc` reproduction command.
5. The exact harness CBMC verified is committed as `<function>.harness.c` alongside each report.

## Caveats every reviewer should know

- **Realism nondeterminism**: the LLM can flip on the same CEx across runs (~10% on borderline cases). We use the strongest realistic CEx per function; downgraded CExes for the same function are preserved in `bug_reports/<property>.json` in the sweep artifact tree.
- **Pre-classifier disabled by default**: an earlier static filter was killing seed bugs before realism could see them. It's off now.
- **Realism endorses ≠ verified**: realism's reasoning is plausible but the LLM may hypothesize an upstream condition that isn't actually reachable. Manual code audit or successful PoC reproduction is the gold standard before reporting upstream.
- **Reports auto-generated** by `bmc_agent/report_generator.py`; reviewers should treat them as primary-source audit-trail dumps, not as polished disclosures.

