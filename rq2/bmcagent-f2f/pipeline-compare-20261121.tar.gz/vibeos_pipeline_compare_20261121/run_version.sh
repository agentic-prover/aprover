#!/usr/bin/env bash
set -euo pipefail

VERSION="${1:-}"
ROOT="/mnt/disk7/jw_bmc/experiments/vibeos_pipeline_compare_20261121"
ADAPT_ROOT="/mnt/disk7/jw_bmc/experiments/deepseek_low_vibeos_adapt_20261121"
KERNEL="/mnt/disk7/jw_bmc/vibeos/kernel"
CBMC_BIN="/mnt/disk7/jw_bmc/rebuttal_icse27/tools/cbmc-5.95.1/usr/bin"
PYTHON="/mnt/disk7/jw_bmc/rebuttal_icse27/code/main_b9314c7/.venv/bin/python"
PORT="${DEEPSEEK_LOW_PROXY_PORT:-8893}"
ONLY_FUNCTIONS="${DEEPSEEK_LOW_FUNCTIONS:-}"

case "$VERSION" in
  f2f31711e)
    CODE="/mnt/disk7/jw_bmc/worktrees/f2f31711e"
    EXPECTED="f2f31711e5d0317ff21d16fd03cd912b152ea202"
    ;;
  b9314c7)
    CODE="/mnt/disk7/jw_bmc/rebuttal_icse27/code/main_b9314c7"
    EXPECTED="b9314c704c1142d195ae43abde4ad9e03f84aaa8"
    ;;
  8c1c50c)
    CODE="/mnt/disk7/jw_bmc/aprover_paper_artifacts_review"
    EXPECTED="8c1c50cb7f61e19bd6bbed9872bc7e988112d99b"
    ;;
  *)
    echo "usage: $0 <f2f31711e|b9314c7|8c1c50c>" >&2
    exit 2
    ;;
esac

actual="$(git -C "$CODE" rev-parse HEAD)"
if [ "$actual" != "$EXPECTED" ]; then
  echo "unexpected source commit: got $actual expected $EXPECTED" >&2
  exit 4
fi
if [ -n "$(git -C "$CODE" status --porcelain --untracked-files=normal -- bmc_agent examples)" ]; then
  echo "uncommitted bmc_agent/examples changes are present in $CODE" >&2
  exit 4
fi

if ! curl --silent --show-error --fail --max-time 5 \
  "http://127.0.0.1:$PORT/health" \
  | jq -e '
      .reserved_usd == 0
      and .denied == 0
      and .model == "deepseek-flash"
      and .thinking == "enabled"
      and .reasoning_effort == "low"
      and .min_output_tokens == 32768
    ' >/dev/null
then
  echo "DeepSeek low-reasoning proxy is not healthy on port $PORT" >&2
  exit 3
fi

RUN_ROOT="${DEEPSEEK_LOW_RUN_ROOT:-$ROOT/runs/$VERSION}"
if [ -e "$RUN_ROOT" ]; then
  echo "refusing to reuse existing run root: $RUN_ROOT" >&2
  exit 2
fi
mkdir -p "$RUN_ROOT"

printf '%s\n' \
  $'setting\tvalue' \
  $'code_commit\t'"$actual" \
  $'code_root\t'"$CODE" \
  $'vibeos_commit\t866bfb9b7fc554b5b8e0939b4626bcf0416b8b19' \
  $'cbmc\t5.95.1' \
  $'python\t'"$PYTHON" \
  $'python_version\t'"$("$PYTHON" -V 2>&1)" \
  $'model\tdeepseek-flash' \
  $'thinking\tenabled' \
  $'reasoning_effort\tlow' \
  $'proxy_min_output_tokens\t32768' \
  $'llm_timeout_s\t180' \
  $'max_tokens_cap\t32768' \
  $'c_backend\tcbmc' \
  $'dynamic_validation\toff' \
  $'realism_check\ton' \
  $'realism_thinking\toff' \
  $'phase_3e_triage\tadvisory_on' \
  $'bmc_config_agent\ton' \
  $'reproducer_agent\ton' \
  $'feedback_loop\ton' \
  $'agentic_harness_repair\ton' \
  $'per_function_time_budget_s\t180' \
  $'module_timeout_s\t3600' \
  > "$RUN_ROOT/fixed_config.tsv"
printf 'script\tsha256\n%s\t%s\n' \
  "$ROOT/run_version.sh" \
  "$(sha256sum "$ROOT/run_version.sh" | awk '{print $1}')" \
  > "$RUN_ROOT/script_provenance.tsv"

printf '%s\n' \
  $'module\tfunction' \
  $'elf\telf_process_relocations' \
  $'fb\tfb_draw_char' \
  $'memory\tmalloc' \
  $'string\tmemmove' \
  > "$RUN_ROOT/selected_functions.tsv"

for entry in \
  "elf elf_process_relocations" \
  "fb fb_draw_char" \
  "memory malloc" \
  "string memmove"
do
  read -r module function <<< "$entry"
  if [ -n "$ONLY_FUNCTIONS" ]; then
    case ",$ONLY_FUNCTIONS," in
      *",$module/$function,"*) ;;
      *) continue ;;
    esac
  fi
  run_dir="$RUN_ROOT/$module/$function"
  mkdir -p "$run_dir/src"
  cp "$KERNEL/$module.c" "$run_dir/src/"
  tag="low__${VERSION}__${module}__${function}"

  {
    echo "[RUN] version=$VERSION"
    echo "[RUN] code=$actual"
    echo "[RUN] code_root=$CODE"
    echo "[RUN] vibeos=$(git -C /mnt/disk7/jw_bmc/vibeos rev-parse HEAD)"
    echo "[RUN] cbmc=$("$CBMC_BIN/cbmc" --version)"
    echo "[RUN] python=$("$PYTHON" -V 2>&1)"
    echo "[RUN] module=$module function=$function"
    echo "[RUN] model=deepseek-flash thinking=enabled reasoning_effort=low"
    echo "[RUN] proxy=http://127.0.0.1:$PORT/deepseek/$tag/api/v1"
    echo "[RUN] start=$(date -Iseconds)"
  } > "$run_dir/run.log"

  start_s="$(date +%s)"
  set +e
  (
    cd "$CODE"
    ulimit -v 42000000
    env -i \
      HOME="$HOME" \
      PATH="$CBMC_BIN:/usr/local/bin:/usr/bin:/bin" \
      LANG="C.UTF-8" \
      LC_ALL="C.UTF-8" \
      TZ="Asia/Dubai" \
      TMPDIR="/tmp" \
      BMC_AGENT_LLM_DEFAULT_PROVIDER="openai" \
      BMC_AGENT_LLM_DEFAULT_MODEL="deepseek-flash" \
      BMC_AGENT_LLM_DEFAULT_BASE_URL="http://127.0.0.1:$PORT/deepseek/$tag/api/v1" \
      BMC_AGENT_LLM_DEFAULT_API_KEY="loopback-proxy" \
      BMC_AGENT_LLM_TIMEOUT_S="180" \
      BMC_AGENT_LLM_MAX_TOKENS_CAP="32768" \
      BMC_AGENT_C_BACKEND="cbmc" \
      BMC_AGENT_ENABLE_REALISM_CHECK="true" \
      BMC_AGENT_ENABLE_REALISM_THINKING="false" \
      BMC_AGENT_ENABLE_DYNAMIC_VALIDATION="false" \
      BMC_AGENT_ENABLE_PHASE_3E_TRIAGE="true" \
      BMC_AGENT_ENABLE_BMC_CONFIG_AGENT="true" \
      BMC_AGENT_ENABLE_REPRODUCER_AGENT="true" \
      BMC_AGENT_ENABLE_FEEDBACK_LOOP="true" \
      BMC_AGENT_ENABLE_AGENTIC_HARNESS_REPAIR="true" \
      timeout 3600 "$PYTHON" -m bmc_agent.cli verify-dir \
        --source-dir "$run_dir/src" \
        --driver "vibeos_${module}" \
        --include-dir "$KERNEL" \
        --include-dir "$KERNEL/libc" \
        --agentic \
        --threat-model security \
        --threat-model-context examples/vibeos/threat_model_context.md \
        --functions "$function" \
        --per-function-time-budget 180 \
        --output "$run_dir/artifacts" \
        --no-dynamic-validation \
        --enable-realism-check \
        --enable-triage \
        --enable-bmc-config-agent \
        --enable-reproducer-agent \
        --enable-feedback-loop
  ) >> "$run_dir/run.log" 2>&1
  rc=$?
  set -e

  end_s="$(date +%s)"
  echo "[RUN] end=$(date -Iseconds) rc=$rc wall_s=$((end_s - start_s))" >> "$run_dir/run.log"
  printf '%s\t%s\t%s\t%s\n' "$module" "$function" "$rc" "$((end_s - start_s))" \
    >> "$RUN_ROOT/exit_codes.tsv"
done
