# DeepSeek low-reasoning representative comparison

Date: 2026-11-21

## Scope

- BMC-Agent: `b9314c7`
- VibeOS: `866bfb9`
- CBMC: 5.95.1
- Model: `deepseek-flash`
- Thinking: enabled, `reasoning_effort=low`
- Configuration: Full with dynamic replay off, realism on, advisory triage on,
  merged BMC-config/reproducer/feedback layers on
- Functions: one representative from each of `elf`, `fb`, `memory`, `string`

The run used `--functions`, so this is an adaptation smoke. It is not a strict
rerun of the original whole-module Claude experiment.

## Function results

| module/function | Claude Full baseline | DeepSeek low | consistency |
|---|---|---|---|
| `elf_process_relocations` | 3 named properties: `pointer_dereference.5`, `pointer_arithmetic.5`, `overflow.1`; all realistic | Same 3 named properties; all realistic | Main findings consistent. Classifier outcome changed from `latent` to `real_bug`. |
| `fb_draw_char` | 2 named latent properties: `pointer_dereference.7`, `pointer_arithmetic.3`; both realistic | 8 deduped properties, all latent. One persisted latent report: `pointer_dereference.7`, realism `unrealistic`, triage `latent`. No named per-bug reports. | Partially consistent: same broad overflow/pointer categories, but persisted finding count and realism verdict differ. |
| `malloc` | Raw CEx is `real_bug`; realism says `unrealistic`; feedback verifies clean; final spurious/unlikely | Raw CEx is `real_bug`; realism says `realistic`; triage gives latent; one persisted `malloc.overflow.1` latent report | Not consistent at the final decision. |
| `memmove` | `pointer.1/2/3` classified real; realism filters all as `unlikely` | Same 3 properties; realism filters all as `unlikely` | Consistent final decision: no confirmed finding. |

## Run statistics

| function | calls | wall seconds | prompt tokens | completion tokens | reasoning tokens | estimated peak cost |
|---|---:|---:|---:|---:|---:|---:|
| `elf_process_relocations` | 98 | 895 | 674,628 | 158,730 | 128,446 | $0.2387 |
| `fb_draw_char` | 68 | 643 | 344,659 | 109,937 | 90,161 | $0.1759 |
| `malloc` | 22 | 226 | 136,705 | 39,375 | 33,173 | $0.0640 |
| `memmove` | 59 | 862 | 615,132 | 153,250 | 136,338 | $0.2271 |
| **total** | **247** | **2,626** | **1,771,124** | **461,292** | **388,118** | **$0.7057** |

All 247 representative-run proxy calls returned HTTP 200. The estimate is based
on peak list prices; it is not an account invoice.

The official DeepSeek balance changed from `260.43 CNY` to `249.09 CNY` across
all attempted runs, smokes, and discarded partial attempts: `11.34 CNY` total.

## Conclusion

The DeepSeek low-reasoning adapter runs the Full pipeline correctly. It also
reproduces the central ELF findings and preserves the memmove precision filter.
It is not a drop-in semantic replacement: `malloc` changes from filtered-clean
to latent, and `fb_draw_char` loses the persisted `pointer_arithmetic.3`
finding that Claude retained. A 47-function DeepSeek sweep would therefore be a
new model-robustness experiment, not a reproduction of the Claude results.

## Raw paths

- Successful run: `runs_min32k/`
- Proxy requests/responses/usage: `proxy_min32k/`
- Proxy implementation: `deepseek_low_proxy.py`
- Runner: `run_representatives.sh`
- Preserved partial attempts: `runs/` and `runs_retry_32768/`
