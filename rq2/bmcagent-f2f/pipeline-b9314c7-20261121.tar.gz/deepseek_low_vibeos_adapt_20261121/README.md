# VibeOS DeepSeek low-reasoning adaptation check

Purpose: verify that the `b9314c7` Full configuration can run against
`deepseek-flash` with low reasoning and reproduce representative outcomes from
the existing Claude Sonnet 4.6 ablation.

Representative functions:

| module | function | existing Full Claude outcome |
|---|---|---|
| elf | `elf_process_relocations` | 3 confirmed latent findings |
| fb | `fb_draw_char` | confirmed latent finding plus one unlabeled property |
| memory | `malloc` | no final finding; realism cleaned a known bug |
| string | `memmove` | no final finding; known pedantic false positive filtered |

The proxy injects `thinking={"type":"enabled"}` and
`reasoning_effort="low"` into every ordinary and tool-use request. It records
the full request/response, usage, estimated peak cost, and a hard local budget.
