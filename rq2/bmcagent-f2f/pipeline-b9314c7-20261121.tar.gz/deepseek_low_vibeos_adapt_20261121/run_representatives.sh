#!/usr/bin/env bash
set -euo pipefail

ROOT="/mnt/disk7/jw_bmc/experiments/deepseek_low_vibeos_adapt_20261121"
CODE="/mnt/disk7/jw_bmc/rebuttal_icse27/code/main_b9314c7"
KERNEL="/mnt/disk7/jw_bmc/vibeos/kernel"
CBMC_BIN="/mnt/disk7/jw_bmc/rebuttal_icse27/tools/cbmc-5.95.1/usr/bin"
PORT="${DEEPSEEK_LOW_PROXY_PORT:-8891}"
RUN_ROOT="${DEEPSEEK_LOW_RUN_ROOT:-$ROOT/runs}"

if [ -e "$RUN_ROOT" ]; then
  echo "refusing to reuse existing run root: $RUN_ROOT" >&2
  exit 2
fi

if ! curl --silent --show-error --fail --max-time 5 \
  "http://127.0.0.1:$PORT/health" \
  | jq -e '.reserved_usd == 0 and .denied == 0' >/dev/null
then
  echo "DeepSeek low-reasoning proxy is not healthy on port $PORT" >&2
  exit 3
fi

mkdir -p "$RUN_ROOT"
printf '%s\n' \
  $'setting\tvalue' \
  $'code_commit\tb9314c704c1142d195ae43abde4ad9e03f84aaa8' \
  $'vibeos_commit\t866bfb9b7fc554b5b8e0939b4626bcf0416b8b19' \
  $'cbmc\t5.95.1' \
  $'model\tdeepseek-flash' \
  $'thinking\tenabled' \
  $'reasoning_effort\tlow' \
  $'proxy_min_output_tokens\t32768' \
  $'llm_timeout_s\t180' \
  $'max_tokens_cap\t32768' \
  $'dynamic_validation\toff' \
  $'realism_check\ton' \
  $'realism_thinking\toff' \
  $'phase_3e_triage\tadvisory_on' \
  $'bmc_config_agent\ton' \
  $'reproducer_agent\ton' \
  $'feedback_loop\ton' \
  $'agentic_harness_repair\ton' \
  $'per_function_time_budget_s\t180' \
  $'module_timeout_s\t3600' \
  > "$RUN_ROOT/fixed_config.tsv"
printf 'script\tsha256\n%s\t%s\n' \
  "$ROOT/run_representatives.sh" \
  "$(sha256sum "$ROOT/run_representatives.sh" | awk '{print $1}')" \
  > "$RUN_ROOT/script_provenance.tsv"

printf '%s\n' \
  $'module\tfunction\tbaseline_Full_Claude_outcome' \
  $'elf\telf_process_relocations\t3 confirmed latent findings' \
  $'fb\tfb_draw_char\tconfirmed latent finding + 1 unlabeled' \
  $'memory\tmalloc\tno final finding; realism cleaned a known bug' \
  $'string\tmemmove\tno final finding; known pedantic FP filtered' \
  > "$RUN_ROOT/selected_functions.tsv"

for entry in \
  "elf elf_process_relocations 3_confirmed_latent" \
  "fb fb_draw_char 1_confirmed_latent_1_unlabeled" \
  "memory malloc no_final_known_bug_cleaned" \
  "string memmove no_final_known_fp_cleaned"
do
  read -r module function expectation <<< "$entry"
  run_dir="$RUN_ROOT/$module/$function"
  mkdir -p "$run_dir/src"
  cp "$KERNEL/$module.c" "$run_dir/src/"
  tag="low__${module}__${function}"

  {
    echo "[RUN] code=$("$CODE/.venv/bin/python" -c 'import subprocess; print(subprocess.check_output(["git", "-C", "'"$CODE"'", "rev-parse", "HEAD"], text=True).strip())')"
    echo "[RUN] vibeos=$(git -C /mnt/disk7/jw_bmc/vibeos rev-parse HEAD)"
    echo "[RUN] cbmc=$("$CBMC_BIN/cbmc" --version)"
    echo "[RUN] module=$module function=$function expectation=$expectation"
    echo "[RUN] model=deepseek-flash thinking=enabled reasoning_effort=low"
    echo "[RUN] proxy=http://127.0.0.1:$PORT/deepseek/$tag/api/v1"
    echo "[RUN] start=$(date -Iseconds)"
  } > "$run_dir/run.log"

  start_s="$(date +%s)"
  set +e
  (
    cd "$CODE"
    ulimit -v 42000000
    env -i \
      HOME="$HOME" \
      PATH="$CBMC_BIN:/usr/local/bin:/usr/bin:/bin" \
      LANG="C.UTF-8" \
      LC_ALL="C.UTF-8" \
      TZ="Asia/Dubai" \
      TMPDIR="/tmp" \
      BMC_AGENT_LLM_DEFAULT_PROVIDER="openai" \
      BMC_AGENT_LLM_DEFAULT_MODEL="deepseek-flash" \
      BMC_AGENT_LLM_DEFAULT_BASE_URL="http://127.0.0.1:$PORT/deepseek/$tag/api/v1" \
      BMC_AGENT_LLM_DEFAULT_API_KEY="loopback-proxy" \
      BMC_AGENT_LLM_TIMEOUT_S="180" \
      BMC_AGENT_LLM_MAX_TOKENS_CAP="32768" \
      BMC_AGENT_ENABLE_REALISM_CHECK="true" \
      BMC_AGENT_ENABLE_REALISM_THINKING="false" \
      BMC_AGENT_ENABLE_DYNAMIC_VALIDATION="false" \
      BMC_AGENT_ENABLE_PHASE_3E_TRIAGE="true" \
      BMC_AGENT_ENABLE_BMC_CONFIG_AGENT="true" \
      BMC_AGENT_ENABLE_REPRODUCER_AGENT="true" \
      BMC_AGENT_ENABLE_FEEDBACK_LOOP="true" \
      BMC_AGENT_ENABLE_AGENTIC_HARNESS_REPAIR="true" \
      timeout 3600 "$CODE/.venv/bin/python" -m bmc_agent.cli verify-dir \
        --source-dir "$run_dir/src" \
        --driver "vibeos_${module}" \
        --include-dir "$KERNEL" \
        --include-dir "$KERNEL/libc" \
        --agentic \
        --threat-model security \
        --threat-model-context examples/vibeos/threat_model_context.md \
        --functions "$function" \
        --per-function-time-budget 180 \
        --output "$run_dir/artifacts" \
        --no-dynamic-validation \
        --enable-realism-check \
        --enable-triage \
        --enable-bmc-config-agent \
        --enable-reproducer-agent \
        --enable-feedback-loop
  ) >> "$run_dir/run.log" 2>&1
  rc=$?
  set -e

  end_s="$(date +%s)"
  echo "[RUN] end=$(date -Iseconds) rc=$rc wall_s=$((end_s - start_s))" >> "$run_dir/run.log"
  printf '%s\t%s\t%s\t%s\n' "$module" "$function" "$rc" "$((end_s - start_s))" \
    >> "$RUN_ROOT/exit_codes.tsv"
done
