#!/usr/bin/env python3
"""Loopback DeepSeek proxy for the VibeOS adaptation smoke test.

The historical BMC-Agent revision used for this check does not know how to
request DeepSeek's low reasoning mode.  This proxy keeps that source revision
unchanged, injects the low-reasoning options into every Chat Completions
request, and records the exact request/response exchange.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import httpx


UPSTREAM = "https://api.deepseek.com/v1"
PEAK_USD_PER_MTOK = {
    "input_cache_hit": 0.006,
    "input_cache_miss": 0.30,
    "output": 1.20,
}
_TAG_RE = re.compile(r"^[A-Za-z0-9_-]+$")


def _usage_summary(usage: dict) -> dict:
    if not usage:
        return {}
    details = usage.get("prompt_tokens_details") or {}
    cache_hit = (
        usage.get("prompt_cache_hit_tokens")
        or details.get("cached_tokens")
        or 0
    )
    prompt = int(usage.get("prompt_tokens") or 0)
    completion = int(usage.get("completion_tokens") or 0)
    return {
        "prompt_tokens": prompt,
        "completion_tokens": completion,
        "total_tokens": int(
            usage.get("total_tokens") or prompt + completion
        ),
        "cache_hit_tokens": int(cache_hit),
        "cache_miss_tokens": max(0, prompt - int(cache_hit)),
        "reasoning_tokens": int(
            (usage.get("completion_tokens_details") or {}).get(
                "reasoning_tokens"
            )
            or 0
        ),
    }


def _estimated_peak_cost(summary: dict) -> float:
    if not summary:
        return 0.0
    return (
        summary["cache_hit_tokens"] * PEAK_USD_PER_MTOK["input_cache_hit"]
        + summary["cache_miss_tokens"]
        * PEAK_USD_PER_MTOK["input_cache_miss"]
        + summary["completion_tokens"] * PEAK_USD_PER_MTOK["output"]
    ) / 1_000_000


def _reservation_usd(body: bytes, max_tokens: int) -> float:
    # One byte per input token is deliberately conservative for the local meter.
    return (
        len(body) * PEAK_USD_PER_MTOK["input_cache_miss"]
        + max_tokens * PEAK_USD_PER_MTOK["output"]
    ) / 1_000_000


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8891)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--budget-usd", type=float, required=True)
    parser.add_argument("--max-calls", type=int, default=800)
    parser.add_argument("--min-output-tokens", type=int, default=32768)
    args = parser.parse_args()

    key = os.environ.get("DEEPSEEK_API_KEY", "").strip()
    if not key:
        parser.error("DEEPSEEK_API_KEY is not set")
    if (
        args.budget_usd <= 0
        or args.max_calls < 1
        or args.min_output_tokens < 1
    ):
        parser.error("budget, max-calls, and min-output-tokens must be positive")

    args.output.mkdir(parents=True, exist_ok=True)
    calls_dir = args.output / "calls"
    calls_dir.mkdir(exist_ok=True)
    call_log = args.output / "llm_calls.jsonl"
    if call_log.exists():
        parser.error("use a fresh output directory")

    client = httpx.Client(
        timeout=httpx.Timeout(240.0, connect=15.0),
        follow_redirects=False,
    )
    state = {
        "calls": 0,
        "completed_calls": 0,
        "reserved_usd": 0.0,
        "spent_usd": 0.0,
        "denied": 0,
    }
    lock = threading.Lock()

    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, *_):
            return

        def _json_reply(self, status: int, data: dict) -> None:
            body = json.dumps(data).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Connection", "close")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self) -> None:
            if self.path != "/health":
                self._json_reply(404, {"error": {"message": "unknown endpoint"}})
                return
            with lock:
                data = {
                    **state,
                    "budget_usd": args.budget_usd,
                    "model": "deepseek-flash",
                    "thinking": "enabled",
                    "reasoning_effort": "low",
                    "min_output_tokens": args.min_output_tokens,
                }
            self._json_reply(200, data)

        def do_POST(self) -> None:
            parts = self.path.strip("/").split("/")
            if (
                len(parts) != 6
                or parts[0] != "deepseek"
                or parts[2:] != ["api", "v1", "chat", "completions"]
                or not _TAG_RE.fullmatch(parts[1])
            ):
                self._json_reply(
                    404,
                    {
                        "error": {
                            "message": (
                                "expected "
                                "/deepseek/<tag>/api/v1/chat/completions"
                            )
                        }
                    },
                )
                return

            tag = parts[1]
            try:
                size = int(self.headers.get("Content-Length", "0"))
                if not 0 < size < 16 * 1024 * 1024:
                    raise ValueError("request size out of range")
                request_body = self.rfile.read(size)
                payload = json.loads(request_body)
                model = str(payload["model"])
                original = dict(payload)
                requested_max_tokens = int(payload.get("max_tokens") or 4096)
                effective_max_tokens = max(
                    requested_max_tokens, args.min_output_tokens
                )
                payload["max_tokens"] = effective_max_tokens
                reservation = _reservation_usd(
                    request_body, effective_max_tokens
                )
            except (ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
                self._json_reply(400, {"error": {"message": str(exc)}})
                return

            with lock:
                if (
                    state["calls"] >= args.max_calls
                    or state["spent_usd"] + state["reserved_usd"] + reservation
                    > args.budget_usd
                ):
                    state["denied"] += 1
                    denial = {
                        "timestamp": time.time(),
                        "tag": tag,
                        "reservation_usd": reservation,
                        **state,
                    }
                    with (args.output / "denials.jsonl").open("a") as stream:
                        stream.write(json.dumps(denial) + "\n")
                    self._json_reply(
                        402,
                        {
                            "error": {
                                "message": (
                                    "local DeepSeek pilot budget reached; "
                                    "no upstream request sent"
                                )
                            }
                        },
                    )
                    return
                state["calls"] += 1
                state["reserved_usd"] += reservation
                index = state["calls"]

            payload["thinking"] = {"type": "enabled"}
            payload["reasoning_effort"] = "low"
            if payload.get("stream"):
                stream_options = dict(payload.get("stream_options") or {})
                stream_options["include_usage"] = True
                payload["stream_options"] = stream_options

            request_hash = hashlib.sha256(
                json.dumps(original, sort_keys=True).encode()
            ).hexdigest()
            call_dir = calls_dir / tag / f"{index:05d}"
            call_dir.mkdir(parents=True)
            (call_dir / "request_original.json").write_text(
                json.dumps(original, indent=2)
            )
            (call_dir / "request_sent.json").write_text(
                json.dumps(payload, indent=2)
            )

            started = time.monotonic()
            usage: dict = {}
            response_model = None
            reasoning_chars = 0
            streamed = bool(payload.get("stream"))
            status = 502
            try:
                request = client.build_request(
                    "POST",
                    UPSTREAM + "/chat/completions",
                    json=payload,
                    headers={
                        "Authorization": "Bearer " + key,
                        "Content-Type": "application/json",
                        "Accept": "text/event-stream" if streamed else "application/json",
                    },
                )
                if streamed:
                    upstream = client.send(request, stream=True)
                    status = upstream.status_code
                    raw_parts: list[bytes] = []
                    self.send_response(status)
                    content_type = upstream.headers.get(
                        "Content-Type", "text/event-stream"
                    )
                    self.send_header("Content-Type", content_type)
                    self.send_header("Cache-Control", "no-cache")
                    self.send_header("Connection", "close")
                    self.end_headers()
                    try:
                        for line in upstream.iter_lines():
                            wire = (line + "\n").encode()
                            raw_parts.append(wire)
                            self.wfile.write(wire)
                            self.wfile.flush()
                            if not line.startswith("data:"):
                                continue
                            data_str = line[5:].strip()
                            if not data_str or data_str == "[DONE]":
                                continue
                            try:
                                chunk = json.loads(data_str)
                            except json.JSONDecodeError:
                                continue
                            response_model = chunk.get("model") or response_model
                            if chunk.get("usage"):
                                usage = chunk["usage"]
                            for choice in chunk.get("choices") or []:
                                delta = choice.get("delta") or {}
                                reasoning = delta.get("reasoning_content")
                                if reasoning:
                                    reasoning_chars += len(str(reasoning))
                    finally:
                        upstream.close()
                    (call_dir / "response.sse").write_bytes(b"".join(raw_parts))
                else:
                    upstream = client.post(
                        UPSTREAM + "/chat/completions",
                        json=payload,
                        headers={
                            "Authorization": "Bearer " + key,
                            "Content-Type": "application/json",
                            "Accept": "application/json",
                        },
                    )
                    status = upstream.status_code
                    body = upstream.content
                    (call_dir / "response.json").write_bytes(body)
                    try:
                        parsed = upstream.json()
                    except ValueError:
                        parsed = {}
                    response_model = parsed.get("model")
                    usage = parsed.get("usage") or {}
                    for choice in parsed.get("choices") or []:
                        message = choice.get("message") or {}
                        reasoning = message.get("reasoning_content")
                        if reasoning:
                            reasoning_chars += len(str(reasoning))
                    self.send_response(status)
                    self.send_header(
                        "Content-Type",
                        upstream.headers.get("Content-Type", "application/json"),
                    )
                    self.send_header("Content-Length", str(len(body)))
                    self.send_header("Connection", "close")
                    self.end_headers()
                    self.wfile.write(body)
            except (httpx.HTTPError, BrokenPipeError, ConnectionResetError) as exc:
                error = str(exc).replace(key, "[REDACTED]")
                status = 502
                error_body = json.dumps({"error": {"message": error}}).encode()
                (call_dir / "proxy_error.txt").write_text(error)
                try:
                    self._json_reply(502, {"error": {"message": error}})
                except (BrokenPipeError, ConnectionResetError):
                    pass

            summary = _usage_summary(usage)
            estimated_cost = _estimated_peak_cost(summary)
            charged = estimated_cost if summary else reservation
            record = {
                "index": index,
                "tag": tag,
                "model": model,
                "response_model": response_model,
                "status": status,
                "stream": streamed,
                "thinking": "enabled",
                "reasoning_effort": "low",
                "requested_max_tokens": requested_max_tokens,
                "effective_max_tokens": effective_max_tokens,
                "reasoning_content_chars": reasoning_chars,
                "request_sha256": request_hash,
                "latency_s": round(time.monotonic() - started, 4),
                "usage": summary,
                "estimated_peak_cost_usd": estimated_cost,
                "meter_charge_usd": charged,
                "cache_dir": str(call_dir),
                "timestamp": time.time(),
            }
            with lock:
                state["reserved_usd"] -= reservation
                state["spent_usd"] += charged
                state["completed_calls"] += 1
                with call_log.open("a") as stream:
                    stream.write(json.dumps(record) + "\n")

    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    print(
        json.dumps(
            {
                "listening": f"127.0.0.1:{args.port}",
                "model": "deepseek-flash",
                "thinking": "enabled",
                "reasoning_effort": "low",
                "min_output_tokens": args.min_output_tokens,
                "budget_usd": args.budget_usd,
                "max_calls": args.max_calls,
            }
        ),
        flush=True,
    )
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        client.close()


if __name__ == "__main__":
    main()
