#!/usr/bin/env python3
"""Resume the killed Tier A ESBMC run from its persisted per-case execution log."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import argparse
from datetime import datetime, timezone
from pathlib import Path
import sys
import time


REPO = Path("/mnt/disk7/jw_bmc/aprover_esbmc_feasibility_fix_20261113")
OUTPUT = Path(__file__).resolve().parent
MANIFEST = OUTPUT / "run_manifest.json"
EXECUTION = OUTPUT / "execution.json"
STATUS = OUTPUT / "resume_status.json"


def read(path: Path):
    return json.loads(path.read_text())


def write(path: Path, value) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2) + "\n")
    tmp.replace(path)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--max-seconds",
        type=float,
        default=0,
        help="Stop cleanly after finishing a case once this many seconds have elapsed.",
    )
    args = parser.parse_args()
    output = OUTPUT.resolve()
    manifest = read(MANIFEST)
    executions = read(EXECUTION) if EXECUTION.exists() else []
    completed = {row["name"] for row in executions}

    key = os.environ.get("OPENROUTER_API_KEY", "")
    if not key:
        raise SystemExit("OPENROUTER_API_KEY is required")

    env = os.environ.copy()
    env.update(manifest["environment"])
    env["OPENROUTER_API_KEY"] = key
    env["BMC_AGENT_LLM_DEFAULT_API_KEY"] = key
    env["BMC_AGENT_LLM_API_KEY"] = key
    env["ANTHROPIC_API_KEY"] = ""

    sys.path.insert(0, str(REPO))
    run_spec = importlib.util.spec_from_file_location(
        "paper_run", REPO / "experiments/paper_reproduction/run.py"
    )
    paper_run = importlib.util.module_from_spec(run_spec)
    run_spec.loader.exec_module(paper_run)
    collect_spec = importlib.util.spec_from_file_location(
        "paper_collect", REPO / "experiments/paper_reproduction/collect.py"
    )
    paper_collect = importlib.util.module_from_spec(collect_spec)
    collect_spec.loader.exec_module(paper_collect)

    jobs = manifest["jobs"]
    if len(jobs) != 27:
        raise SystemExit(f"expected 27 jobs, found {len(jobs)}")
    names = [job["name"] for job in jobs]
    if len(set(names)) != len(names):
        raise SystemExit("duplicate job names in manifest")
    if not completed <= set(names):
        raise SystemExit("execution log contains names absent from manifest")

    started_at = datetime.now(timezone.utc).isoformat()
    started_monotonic = time.monotonic()
    status = {
        "kind": "resume_after_external_sigterm",
        "started_at": started_at,
        "manifest_sha256": sha256(MANIFEST),
        "completed_before_resume": sorted(completed),
        "quarantined_partial_case": str(
            output
            / "quarantine"
            / "aws_byte_buf_eq_c_str_ignore_case_harness_partial_sigterm"
        ),
        "remaining": [name for name in names if name not in completed],
        "completed_this_resume": [],
        "state": "running",
    }
    write(STATUS, status)

    try:
        for ordinal, job in enumerate(jobs, start=1):
            name = job["name"]
            if name in completed:
                continue
            case_output = Path(job["output"])
            if case_output.exists():
                raise SystemExit(
                    f"refusing to overwrite nonempty job output {case_output}"
                )
            print(f"[{ordinal}/27] running {name}", flush=True)
            result = paper_run.run_job(job, env)
            executions.append(result)
            write(EXECUTION, executions)
            completed.add(name)
            status["completed_this_resume"].append(result)
            status["remaining"] = [candidate for candidate in names if candidate not in completed]
            status["updated_at"] = datetime.now(timezone.utc).isoformat()
            write(STATUS, status)
            if (
                args.max_seconds > 0
                and time.monotonic() - started_monotonic >= args.max_seconds
                and any(candidate not in completed for candidate in names)
            ):
                status["state"] = "paused_for_session_boundary"
                status["paused_at"] = datetime.now(timezone.utc).isoformat()
                status["elapsed_s"] = round(
                    time.monotonic() - started_monotonic, 3
                )
                write(STATUS, status)
                print("paused at planned session boundary", flush=True)
                return 0

        metrics = paper_collect.collect(output)
        write(output / "metrics.json", metrics)
        status["state"] = "complete"
        status["finished_at"] = datetime.now(timezone.utc).isoformat()
        status["metrics"] = metrics
        write(STATUS, status)
        return 0
    except BaseException as exc:
        status["state"] = "failed"
        status["error"] = f"{type(exc).__name__}: {exc}"
        status["finished_at"] = datetime.now(timezone.utc).isoformat()
        write(STATUS, status)
        raise


if __name__ == "__main__":
    raise SystemExit(main())
