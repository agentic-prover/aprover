"""Run the production CLI with a hash-locked saved agent configuration.

No configuration model request is sent. Validation uses the normal live model.
The only prompt normalization allowed is global timeout 300 -> 900 seconds.
"""
import argparse
from dataclasses import asdict, replace
import hashlib
import json
from pathlib import Path
import re
import runpy
import sys
import threading
import time


def require(ok, message):
    if not ok:
        raise SystemExit(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def normalized_prompt(prompt):
    found = re.findall(r'^GLOBAL TIMEOUT DEFAULT: (\d+)s$', prompt, re.M)
    require(len(found) == 1 and found[0] in ('300', '900'), 'Unexpected saved global timeout')
    return re.sub(r'^GLOBAL TIMEOUT DEFAULT: 300s$', 'GLOBAL TIMEOUT DEFAULT: 900s', prompt, flags=re.M)


def prepare_configuration(args):
    from bmc_agent.agents.bmc_config_tools import BmcConfigAgent, _extract_json_object
    require(sha(args.request) == args.request_sha256, 'Saved configuration request hash changed')
    require(sha(args.response) == args.response_sha256, 'Saved configuration response hash changed')
    require(sha(args.source) == args.source_sha256, 'Benchmark source hash changed')
    request = json.loads(args.request.read_text())
    response = json.loads(args.response.read_text())
    require(response['choices'][0]['finish_reason'] == 'stop', 'Incomplete saved response')
    text = response['choices'][0]['message']['content']
    require(_extract_json_object(text) is not None, 'Saved configuration JSON failed to parse')
    prompt = next(m['content'] for m in request['messages'] if m['role'] == 'user')
    require(str(args.source) in json.dumps(request), 'Source is absent from saved tool history')
    before = BmcConfigAgent.parse(object.__new__(BmcConfigAgent), text)
    require(before is not None, 'Saved configuration failed to parse')
    updates = json.loads(args.overrides)
    require(set(updates) <= {'unwind_override', 'timeout_override'}, 'Unsupported flag override')
    require(all(type(v) is int and v > 0 for v in updates.values()), 'Invalid bound override')
    require(updates.get('timeout_override') == 900, 'Matched experiment requires actual timeout 900')
    inline_updates = json.loads(args.inline_overrides)
    require(set(inline_updates) <= set(before.inline_overrides), 'Unknown inline override')
    require(all(type(v) is bool for v in inline_updates.values()), 'Invalid inline override')

    def updated(cfg):
        choices = {name: replace(value, inline=inline_updates[name]) if name in inline_updates else value
                   for name, value in cfg.inline_overrides.items()}
        return replace(cfg, flags=replace(cfg.flags, **updates), inline_overrides=choices)

    after = updated(before)
    expected, effective = asdict(before), asdict(after)
    comparison = json.loads(json.dumps(effective))
    for name in updates:
        comparison['flags'][name] = expected['flags'][name]
    for name in inline_updates:
        comparison['inline_overrides'][name]['inline'] = expected['inline_overrides'][name]['inline']
    require(comparison == expected, 'Unrequested configuration change')
    record = {
        'kind': 'saved_agent_configuration_replay', 'backend': args.c_backend,
        'configuration_llm_calls': 0, 'validation_agents': 'fresh Claude when invoked',
        'source_path': str(args.source), 'source_sha256': args.source_sha256,
        'request_sha256': args.request_sha256, 'response_sha256': args.response_sha256,
        'before': expected, 'effective': effective,
        'explicit_flag_overrides': updates, 'explicit_inline_overrides': inline_updates,
        'expected_cbmc_main_harness_sha256': args.harness_sha256,
        'prompt_policy': 'exact full prompt after only GLOBAL TIMEOUT DEFAULT: 300s -> 900s',
    }
    return BmcConfigAgent, text, prompt, before, after, updated, record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--c-backend', choices=('cbmc', 'esbmc'), required=True)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--source-sha256', required=True)
    parser.add_argument('--request', type=Path, required=True)
    parser.add_argument('--request-sha256', required=True)
    parser.add_argument('--response', type=Path, required=True)
    parser.add_argument('--response-sha256', required=True)
    parser.add_argument('--audit', type=Path, required=True)
    parser.add_argument('--harness-sha256', default='')
    parser.add_argument('--overrides', required=True)
    parser.add_argument('--inline-overrides', default='{}')
    parser.add_argument('--check-only', action='store_true')
    parser.add_argument('--check-json', type=Path)
    parser.add_argument('cli', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    sys.path.insert(0, str(args.repo))
    Agent, text, prompt, before, after, updated, record = prepare_configuration(args)
    cli = args.cli[1:] if args.cli[:1] == ['--'] else args.cli
    require(cli[:1] == ['verify'], 'Expected verify subcommand')
    require('--source' in cli and cli[cli.index('--source') + 1] == str(args.source), 'CLI source mismatch')
    target_prompt = normalized_prompt(prompt)
    if args.check_only:
        from bmc_agent.parser import parse_c_file
        source = parse_c_file(args.source)
        section = prompt.split('STUB CANDIDATE CALLEES ', 1)[1].split('\n\nUse the tools', 1)[0]
        candidates = re.findall(r'^  - (\S+)$', section, re.M)
        rebuilt = Agent.build_prompt(object.__new__(Agent), func=source.get_function_info('main'),
                                     global_unwind=1, global_timeout=900, stub_candidates=candidates)
        require(rebuilt == target_prompt, 'Rebuilt prompt changed beyond authorized timeout line')
        record['rebuilt_prompt_matches'] = True
        if args.check_json:
            args.check_json.write_text(json.dumps(record, indent=2) + '\n')
        print(json.dumps(record, indent=2))
        return
    from bmc_agent.config import Config
    config = Config.from_env()
    require(config.c_backend == args.c_backend, 'Backend differs from frozen plan')
    require(config.cbmc_unwind == 1 and config.cbmc_timeout == 900
            and config.per_function_time_budget_s == 2700, 'Time/default-bound policy changed')
    args.audit.mkdir(parents=True, exist_ok=False)
    (args.audit / 'frozen_config.json').write_text(json.dumps(record, indent=2) + '\n')
    original_parse = Agent.parse

    def saved_call(self, current_prompt):
        require(current_prompt == target_prompt, 'Configuration prompt changed beyond authorized timeout line')
        (args.audit / 'prompt_match.json').write_text(json.dumps({
            'matched_after_only_timeout_normalization': True,
            'saved_sha256': hashlib.sha256(prompt.encode()).hexdigest(),
            'current_sha256': hashlib.sha256(current_prompt.encode()).hexdigest()}) + '\n')
        return text, None

    def fixed_parse(self, raw):
        require(raw == text, 'Unexpected configuration response')
        parsed = original_parse(self, raw)
        require(parsed is not None and asdict(parsed) == record['before'], 'Parsed configuration drifted')
        return updated(parsed)

    Agent._call_llm = saved_call
    Agent.parse = fixed_parse
    import bmc_agent.c_bmc as dispatch
    original_solver = dispatch.run_c_bmc
    lock = threading.Lock()
    call_count = 0

    def observed_solver(*pos, config, **kwargs):
        nonlocal call_count
        backend = getattr(config, 'c_backend', 'cbmc')
        require(backend == args.c_backend, 'Unexpected solver backend')
        actual_timeout = kwargs.get('timeout', config.cbmc_timeout)
        require(0 < actual_timeout <= 900, 'Solver exceeded matched timeout budget')
        actual_unwind = kwargs.get('unwind', config.cbmc_unwind)
        path = Path(kwargs.get('harness_path', pos[0] if pos else ''))
        digest = sha(path)
        with lock:
            call_count += 1
            index = call_count
        if index == 1:
            require(actual_timeout == 900, 'Initial solver did not receive matched 900-second budget')
            require(actual_unwind == (after.flags.unwind_override or 1), 'Initial solver unwind differs from configuration')
            if backend == 'cbmc' and args.harness_sha256:
                require(digest == args.harness_sha256, 'Initial CBMC harness differs from accepted evidence')
        row = {'index': index, 'started_at': time.time(), 'backend': backend,
               'harness_sha256': digest, 'effective_timeout_s': actual_timeout,
               'effective_unwind': actual_unwind,
               'kwargs': {k: str(v) if isinstance(v, Path) else v for k, v in kwargs.items()}}
        with lock, (args.audit / 'effective_solver_calls.jsonl').open('a') as f:
            f.write(json.dumps(row) + '\n')
        print('FIXED_CONFIG_SOLVER ' + json.dumps(row), flush=True)
        return original_solver(*pos, config=config, **kwargs)

    # Patch the shared dispatch before the CLI imports verification modules.
    # Already-imported aliases, if any, retain the same observed dispatch too.
    for module in list(sys.modules.values()):
        if module is not None and getattr(module, 'run_cbmc', None) is original_solver:
            module.run_cbmc = observed_solver
    dispatch.run_c_bmc = observed_solver
    sys.argv = ['bmc_agent.cli', *cli]
    runpy.run_module('bmc_agent.cli', run_name='__main__')


if __name__ == '__main__':
    main()
