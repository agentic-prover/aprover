"""Prepare matched 29-case CBMC/ESBMC plans; never start models or solvers."""
from dataclasses import asdict, replace
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys

HERE = Path(__file__).resolve().parent
MAP = HERE.parent / 'claude29_config_sources.json'
MAP_SHA = '331cc1c72fe8a37f883c91e25bd065ed052d5ab2b10da885e06a8c3c7b27de81'
COMMIT = '70c03013c52031d8b5168693e742b0992de8d333'
CAMERA = Path('/mnt/disk7/jw_bmc/aprover_camera_ready_rq1_rq3_20261104')
LATER = CAMERA / 'artifacts/rq1_ldv_claude4_long_20261112_9870f30'
P54_CIL = '32_7_cilled_const_ok_linux-32_1-drivers--net--wireless--p54--p54usb.ko-ldv_main0_sequence_infinite_withcheck_stateful.cil.out'
P54_CPP = '32_7_cpp_single_drivers-net-wireless-p54-p54usb.cil.out'
MEGARAID = '43_1a_cilled_ok_linux-43_1a-drivers--scsi--megaraid--megaraid_mm.ko-ldv_main0_sequence_infinite_withcheck_stateful.cil.out'
VHOST = '32_7_cilled_const_ok_linux-32_1-drivers--vhost--vhost_net.ko-ldv_main1_sequence_infinite_withcheck_stateful.cil.out'
MEGARAID_STUBS = {'lld_timedout': False, 'mraid_mm_exit': False,
                  'mraid_mm_init': False, 'mraid_mm_open': False}
CBMC_HASHES = {
    P54_CIL: '9c0bd22a996605aec38ee3067f242d60cd9e07c765d3bc9477c031db2ac97e70',
    P54_CPP: 'c75816e43411db15ce9aa8464939c6f750a20eaf2949edc5775e66db4569a4d2',
    MEGARAID: '74f1ea843e45997bc1077c3d568c94047242c1775366111cfb822beafe8526b6',
    VHOST: '0b3a5fd2e9f7f552ea25260acea5f2dc01a3a0808407abbc158d83abdc65cc25',
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def apply_time_budgets(run):
    run.PROFILES['rq1-ldv-guarded'] = {
        **run.PROFILES['rq1-ldv-guarded'], 'solver_timeout': 900, 'case_timeout': 2700,
        'per_function_time_budget_s': 2700,
    }
    original = run.child_environment

    def child_environment(profile, args):
        env, settings = original(profile, args)
        key = 'BMC_AGENT_PER_FUNCTION_TIME_BUDGET_S'
        env[key] = settings[key] = str(profile['per_function_time_budget_s'])
        return env, settings

    run.child_environment = child_environment


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=Path('/mnt/disk7/jw_bmc/aprover_esbmc_ldv_camera_ready_20261112'))
    parser.add_argument('--c-backend', choices=('cbmc', 'esbmc'), required=True)
    parser.add_argument('--port', type=int, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--workers', type=int, default=3)
    args = parser.parse_args()
    assert args.workers > 0 and 1 <= args.port <= 65535
    assert sha(MAP) == MAP_SHA
    mapping = json.loads(MAP.read_text())
    assert len(mapping['rows']) == 29 and mapping['parse_failure_count'] == 0
    assert not args.output.exists(), 'Use a fresh output directory for this matched plan'
    args.repo, args.output = args.repo.resolve(), args.output.resolve()
    sys.path.insert(0, str(args.repo))
    from bmc_agent.agents.bmc_config_tools import BmcConfigAgent, _extract_json_object
    old_manifest = json.loads(Path(mapping['run_manifest_path']).read_text())
    os.environ['PATH'] = old_manifest['environment']['PATH'].split(os.pathsep, 1)[1]
    path = args.repo / 'experiments/paper_reproduction/run.py'
    spec = importlib.util.spec_from_file_location('paired_formal_run', path)
    run = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(run)
    assert run.git('rev-parse', 'HEAD') == COMMIT
    assert not run.git('diff', '--name-only', 'HEAD')
    apply_time_budgets(run)
    tag = 'claude_matched_' + args.c_backend
    command = [str(path), 'rq1-ldv-guarded', '--artifact-root', '/mnt/disk7/jw_bmc/BMC_ICSE',
               '--data-dir', str(CAMERA / 'artifacts/paper_benchmarks'),
               '--c-backend', args.c_backend,
               '--base-url', f'http://127.0.0.1:{args.port}/openrouter/{tag}/api/v1',
               '--model', 'anthropic/claude-sonnet-4.5', '--api-key-env', 'LOCAL_RECORDER_KEY',
               '--workers', str(args.workers), '--trials', '1',
               '--call-log', str(args.output / 'recording/llm_calls.jsonl'), '--output', str(args.output)]
    if args.c_backend == 'cbmc':
        command += ['--cbmc-path', '/mnt/disk7/jw_bmc/rebuttal_icse27/tools/cbmc-5.95.1/usr/bin/cbmc']
    else:
        command += ['--esbmc-path', '/mnt/disk7/jw_bmc/rebuttal_icse27/tools/esbmc-8.3/bin/esbmc']
    sys.argv = command
    status = run.main()
    assert status == 0
    manifest_path = args.output / 'run_manifest.json'
    manifest = json.loads(manifest_path.read_text())
    assert len(manifest['jobs']) == 29 and not manifest['pilot']
    cases = {c['name']: c for c in manifest['cases']}
    assert set(cases) == {r['task_id'] for r in mapping['rows']}
    provenance = args.output / 'provenance'
    provenance.mkdir()
    for p in (MAP, Path(__file__), HERE / 'frozen_config_cli.py'):
        shutil.copy2(p, provenance / p.name)
    neutral = []
    replay = {}
    for row in mapping['rows']:
        task = row['task_id']
        case = cases[task]
        assert case['sha256'] == row['source_sha256'] and sha(case['source']) == case['sha256']
        request_path, response_path = Path(row['request_path']), Path(row['response_path'])
        assert sha(request_path) == row['request_sha256'] and sha(response_path) == row['response_sha256']
        basis = 'original Claude29 configuration'
        if task == VHOST:
            request_path = LATER / 'recording/calls/ldv4_claude_long/00010/request.json'
            response_path = request_path.with_name('response.json')
            basis = 'explicitly selected later Claude vhost configuration, confirmed target and feasibility'
        request = json.loads(request_path.read_text())
        raw = json.loads(response_path.read_text())
        assert raw['choices'][0]['finish_reason'] == 'stop'
        content = raw['choices'][0]['message']['content']
        assert str(case['source']) in json.dumps(request)
        assert _extract_json_object(content) is not None
        cfg = BmcConfigAgent.parse(object.__new__(BmcConfigAgent), content)
        if task != VHOST:
            assert asdict(cfg) == row['parsed_configuration']
        else:
            assert cfg.flags.unwind_override is None
            assert not cfg.inline_overrides['vhost_net_init'].inline and not cfg.inline_overrides['vhost_net_exit'].inline
        updates = {'timeout_override': 900}
        if task in (P54_CIL, P54_CPP):
            updates['unwind_override'] = 1
        if task == MEGARAID:
            updates['unwind_override'] = 2
        inline = MEGARAID_STUBS if task == MEGARAID else {}
        choices = {k: replace(v, inline=inline[k]) if k in inline else v for k, v in cfg.inline_overrides.items()}
        effective = replace(cfg, flags=replace(cfg.flags, **updates), inline_overrides=choices)
        source_record = {
            'task_id': task, 'source_path': case['source'], 'source_sha256': case['sha256'],
            'saved_request': str(request_path), 'saved_response': str(response_path),
            'request_sha256': sha(request_path), 'response_sha256': sha(response_path),
            'source_basis': basis, 'flag_overrides': updates, 'inline_overrides': inline,
            'before': asdict(cfg), 'effective': asdict(effective),
            'expected_cbmc_main_harness_sha256': CBMC_HASHES.get(task, ''),
        }
        neutral.append(source_record)
        dest = provenance / task
        dest.mkdir()
        shutil.copy2(request_path, dest / 'request.json')
        shutil.copy2(response_path, dest / 'response.json')
        job = next(j for j in manifest['jobs'] if j['name'] == task)
        cli = job['command'][3:]
        assert cli[0] == 'verify'
        job['command'] = [sys.executable, str(provenance / 'frozen_config_cli.py'),
                          '--repo', str(args.repo), '--c-backend', args.c_backend,
                          '--source', case['source'], '--source-sha256', case['sha256'],
                          '--request', str(dest / 'request.json'), '--request-sha256', sha(request_path),
                          '--response', str(dest / 'response.json'), '--response-sha256', sha(response_path),
                          '--audit', str(Path(job['output']) / 'fixed_configuration'),
                          '--overrides', json.dumps(updates), '--inline-overrides', json.dumps(inline),
                          '--harness-sha256', CBMC_HASHES.get(task, ''), '--', *cli]
        replay[task] = {**source_record, 'snapshot_request': str(dest / 'request.json'),
                        'snapshot_response': str(dest / 'response.json')}
    neutral.sort(key=lambda r: r['task_id'])
    config_set = {'pipeline_commit': COMMIT, 'model': 'anthropic/claude-sonnet-4.5',
                  'solver_timeout_s': 900, 'case_timeout_s': 2700, 'function_budget_s': 2700,
                  'memory_kib': 42000000, 'rows': neutral}
    config_fingerprint = hashlib.sha256(json.dumps(config_set, sort_keys=True).encode()).hexdigest()
    run.write_json(args.output / 'configuration_set.json', config_set)
    manifest.update(execution_kind='saved_configuration_replay_fresh_validation',
                    configuration_replay=replay, configuration_set_fingerprint=config_fingerprint,
                    configuration_sources_map_sha256=MAP_SHA,
                    wrapper_sha256=sha(provenance / 'frozen_config_cli.py'),
                    preparation_sha256=sha(provenance / 'prepare_plan.py'),
                    configuration_llm_calls=0, planned_workers=args.workers)
    manifest['fingerprint'] = hashlib.sha256(json.dumps({
        k: v for k, v in manifest.items() if k not in ('fingerprint', 'created_at', 'tool_versions')
    }, sort_keys=True).encode()).hexdigest()
    run.write_json(manifest_path, manifest)
    print(json.dumps({'backend': args.c_backend, 'cases': 29, 'configuration_set_fingerprint': config_fingerprint,
                      'execute': False, 'output': str(args.output)}))


if __name__ == '__main__':
    main()
