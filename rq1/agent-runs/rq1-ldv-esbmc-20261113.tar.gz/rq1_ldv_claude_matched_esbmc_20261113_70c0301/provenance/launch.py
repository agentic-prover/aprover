"""Execute the frozen formal LDV plan concurrently; no pipeline modifications."""
import argparse
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from types import SimpleNamespace

import httpx
from prepare_plan import apply_time_budgets


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--key-file', type=Path, required=True)
    p.add_argument('--expect-commit', required=True)
    p.add_argument('--c-backend', choices=('cbmc', 'esbmc'), required=True)
    p.add_argument('--workers', type=int, default=3)
    p.add_argument('--port', type=int, default=8950)
    p.add_argument('--budget-usd', type=float, default=40)
    p.add_argument('--max-calls', type=int, default=1800)
    a = p.parse_args()
    run = load(a.repo / 'experiments/paper_reproduction/run.py', 'formal_run')
    apply_time_budgets(run)
    collect = load(a.repo / 'experiments/paper_reproduction/collect.py', 'formal_collect')
    manifest = json.loads((a.output / 'run_manifest.json').read_text())
    assert a.workers > 0
    assert run.source_snapshot() == manifest['source']
    assert manifest['source']['commit'] == a.expect_commit
    assert not manifest['source']['tracked_changes']
    assert len(manifest['cases']) == len(manifest['jobs']) == 29 and not manifest['pilot']
    assert {c['name'] for c in manifest['cases']} == {j['name'] for j in manifest['jobs']}
    assert len({j['name'] for j in manifest['jobs']}) == 29
    assert manifest['environment'].get('BMC_AGENT_C_BACKEND', 'cbmc') == a.c_backend
    assert all(j['timeout_s'] == 2700 for j in manifest['jobs'])
    assert manifest['settings']['solver_timeout'] == 900
    assert manifest['environment']['BMC_AGENT_CBMC_TIMEOUT'] == '900'
    assert manifest['environment']['BMC_AGENT_PER_FUNCTION_TIME_BUDGET_S'] == '2700'
    assert not (a.output / 'execution.json').exists()
    assert not any((Path(j['output']) / 'run.log').exists() for j in manifest['jobs'])
    for case in manifest['cases']:
        assert run.sha256(Path(case['source'])) == case['sha256']
    assert run.sha256(a.output / 'provenance/frozen_config_cli.py') == manifest['wrapper_sha256']
    assert run.sha256(a.output / 'provenance/prepare_plan.py') == manifest['preparation_sha256']
    recorded = manifest['environment']
    assert recorded['BMC_AGENT_LLM_DEFAULT_MODEL'] == 'anthropic/claude-sonnet-4.5'
    assert recorded['BMC_AGENT_LLM_DEFAULT_BASE_URL'] == f'http://127.0.0.1:{a.port}/openrouter/claude_matched_{a.c_backend}/api/v1'
    args = SimpleNamespace(base_url=recorded['BMC_AGENT_LLM_DEFAULT_BASE_URL'],
                           model=recorded['BMC_AGENT_LLM_DEFAULT_MODEL'], api_key_env='LOCAL_RECORDER_KEY',
                           cbmc_path=Path(recorded['PAPER_REPRO_CBMC_REAL']) if a.c_backend == 'cbmc' else None,
                           c_backend=a.c_backend,
                           esbmc_path=Path(recorded['PAPER_REPRO_ESBMC_REAL']) if a.c_backend == 'esbmc' else None,
                           frama_c_path=None,
                           autospec_root=None, output=a.output)
    os.environ['LOCAL_RECORDER_KEY'] = 'local-recorder-placeholder'
    env, settings = run.child_environment(manifest['settings'], args)
    assert settings == recorded
    assert 'BMC_AGENT_DEEPSEEK_THINKING' not in env
    versions = run.tool_versions(manifest['settings'], args, env)
    manifest['tool_versions'] = versions
    run.write_json(a.output / 'run_manifest.json', manifest)
    provenance = a.output / 'provenance'
    provenance.mkdir(exist_ok=True)
    for path in (Path(__file__), a.repo / 'experiments/paper_reproduction/recording_proxy.py'):
        shutil.copy2(path, provenance / path.name)
    launch = {'command': sys.argv, 'workers': a.workers,
              'hypothesis': 'Compare CBMC and ESBMC on all29 frozen inputs and the same frozen agent configuration set, with matched budgets and fresh Claude validation.',
              'decision': 'Record candidates and target feasibility separately. Inspect new systematic adapter failures and stop affected runs before repairs. Known original-input callback frontend errors remain tool errors. Do not merge best-of runs or change configs per backend.',
              'started_at': time.time(), 'budget_usd': a.budget_usd, 'max_calls': a.max_calls,
              'launcher_sha256': run.sha256(Path(__file__)), 'pipeline_commit': a.expect_commit,
              'preparation_sha256': run.sha256(Path(__file__).with_name('prepare_plan.py')),
              'time_budgets_s': {'solver_default': 900, 'case': 2700, 'function_cumulative': 2700},
              'fresh_configuration_generation': False, 'configuration_set_fingerprint': manifest['configuration_set_fingerprint'], 'c_backend': a.c_backend}
    # Credential location is an operational argument, excluded from saved provenance.
    launch['command'] = [v if i == 0 or sys.argv[i-1] != '--key-file' else '[temporary credential]' for i, v in enumerate(sys.argv)]
    run.write_json(a.output / 'launch.json', launch)
    proxy_command = [sys.executable, str(a.repo / 'experiments/paper_reproduction/recording_proxy.py'),
                     '--port', str(a.port), '--output', str(a.output / 'recording'),
                     '--key-file', str(a.key_file), '--budget-usd', str(a.budget_usd),
                     '--max-calls', str(a.max_calls)]
    results = []
    stop_reason = None
    started = time.monotonic()
    with (a.output / 'recorder.log').open('w') as proxy_log:
        proxy = subprocess.Popen(proxy_command, cwd=a.repo, stdout=proxy_log, stderr=subprocess.STDOUT)
        try:
            with httpx.Client(timeout=2) as client:
                for _ in range(60):
                    if proxy.poll() is not None:
                        raise RuntimeError('recorder exited before startup; see recorder.log')
                    try:
                        health = client.get(f'http://127.0.0.1:{a.port}/health')
                        if health.status_code == 200:
                            break
                    except httpx.HTTPError:
                        pass
                    time.sleep(1)
                else:
                    raise RuntimeError('recorder failed to become ready')
            # Start one previously verified backend case and both restored p54 variants first.
            priority = ('kernelcapi', 'cpp_single_drivers-net-wireless-p54', 'drivers--net--wireless--p54')
            ordered = sorted(manifest['jobs'], key=lambda j: (next((i for i, term in enumerate(priority) if term in j['name']), len(priority)), j['name']))
            run.write_json(a.output / 'scheduling_order.json', [j['name'] for j in ordered])
            jobs = iter(ordered)
            run.write_json(a.output / 'execution.json', [])
            with ThreadPoolExecutor(max_workers=a.workers) as pool:
                active = {}
                def submit_next():
                    job = next(jobs, None)
                    if job is not None:
                        print('START ' + job['name'], flush=True)
                        active[pool.submit(run.run_job, job, env)] = job['name']
                for _ in range(a.workers):
                    submit_next()
                while active:
                    done, _ = wait(active, return_when=FIRST_COMPLETED)
                    for future in done:
                        name = active.pop(future)
                        result = future.result()
                        results.append(result)
                        run.write_json(a.output / 'execution.json', sorted(results, key=lambda r: r['name']))
                        print('DONE ' + json.dumps(result), flush=True)
                    call_log = a.output / 'recording/llm_calls.jsonl'
                    calls = [json.loads(line) for line in call_log.read_text().splitlines()] if call_log.exists() else []
                    if (a.output / 'recording/budget_denials.jsonl').exists() or any(c['status'] in (401,402,403) for c in calls):
                        stop_reason = 'credential or budget failure; stopped scheduling additional cases'
                    if not stop_reason:
                        for _ in done:
                            submit_next()
            metrics = collect.collect(a.output)
            run.write_json(a.output / 'metrics.json', metrics)
            summary = {'completed_cases': len(results), 'wall_s': round(time.monotonic()-started, 3),
                       'stop_reason': stop_reason, 'source_unchanged': run.source_snapshot() == manifest['source'],
                       'target_evidence_counts': metrics.get('target_evidence_counts'),
                       'verdict_counts': metrics.get('verdict_counts'), 'llm': metrics.get('llm')}
            run.write_json(a.output / 'completion.json', summary)
            print('COMPLETE ' + json.dumps(summary), flush=True)
        finally:
            proxy.terminate()
            try:
                proxy.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proxy.kill()
                proxy.wait()
            a.key_file.unlink(missing_ok=True)


if __name__ == '__main__':
    main()
