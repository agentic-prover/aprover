class Main {

  //@ ensures (x != 3 && x != 0) ==> \result == true;
  //@ ensures (x == 0) ==> \result == true;
  //@ ensures (x == 3) ==> \result == true;
  public static boolean f(int x) {
    if (x != 3 && x != 0)
      return true;

    Main inst = new Main();
    return inst.test(x);
  }

  //@ requires x < Integer.MAX_VALUE;
  //@ ensures (x + 1 > 0) ==> \result == true;
  //@ ensures !(x + 1 > 0) ==> \result == false;
  public boolean test(int x) {
    float res = (float) ++x;
    if (res > 0) ;
    else {
      return false;
    }
    return true;
  }
}