class DominantIndex {

    //@ requires nums != null && nums.length >= 1;
    //@ assignable \nothing;
    //@ ensures \result == -1 || (0 <= \result && \result < nums.length);
    //@ ensures \result != -1 ==> (\forall int i_q; 0 <= i_q && i_q < nums.length; nums[\result] >= nums[i_q]);
    public static int dominantIndex(int[] nums) {
        int biggest_index = 0;

        //@ maintaining 0 <= i && i <= nums.length;
        //@ maintaining 0 <= biggest_index && biggest_index < nums.length;
        //@ maintaining (\forall int k; 0 <= k && k < i; nums[biggest_index] >= nums[k]);
        //@ decreases nums.length - i;
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] > nums[biggest_index])
                biggest_index = i;
        }

        //@ maintaining 0 <= i && i <= nums.length;
        //@ maintaining 0 <= biggest_index && biggest_index < nums.length;
        //@ maintaining (\forall int k; 0 <= k && k < nums.length; nums[biggest_index] >= nums[k]);
        //@ decreases nums.length - i;
        for (int i = 0; i < nums.length; i++) {
            if (i != biggest_index && 2 * nums[i] > nums[biggest_index])
                return -1;
        }

        return biggest_index;
    }
}