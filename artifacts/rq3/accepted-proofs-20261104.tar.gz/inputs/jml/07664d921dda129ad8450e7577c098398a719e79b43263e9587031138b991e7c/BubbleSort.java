public class BubbleSort { 
    
    //@ requires array != null;
    //@ requires 0 <= x && x < array.length;
    //@ requires 0 <= y && y < array.length;
    //@ assignable array[x], array[y];
    //@ ensures array[x] == \old(array[y]);
    //@ ensures array[y] == \old(array[x]);
    void swap(int x, int y,  int array[]) {
        int temp;     
        temp = array[x];
        array[x] = array[y];
        array[y] = temp;
    }

    //@ requires arr != null;
    //@ requires arr.length >= 0;
    //@ assignable arr[*];
    //@ ensures \result == arr;
    //@ ensures \result != null;
    //@ ensures \result.length == arr.length;
    int[] bubbleSort(int arr[]) {
        int n = arr.length;

        //@ maintaining 0 <= i && i <= n;
        //@ maintaining n == arr.length;
        //@ decreases n - 1 - i;
        for (int i = 0; i < n-1; i++) {	

            //@ maintaining 0 <= j && j <= n - i - 1;
            //@ maintaining n == arr.length;
            //@ decreases n - i - 1 - j;
            for (int j = 0; j < n-i-1; j++) {
                if (arr[j+1] < arr[j]) {  
		     swap(j, j + 1, arr); 
                } 
	    }
	} 
	return arr;
    } 
}