class Main {

  //@ ensures \result == true;
  //@ assignable \nothing;
  public static boolean f() {
    int a = 3;
    Main inst = new Main();
    int b = 8;
    return inst.test(a, b, a);
  }

  //@ requires x + 3 > Integer.MIN_VALUE && x + 3 <= Integer.MAX_VALUE;
  //@ requires z + 1 <= Integer.MAX_VALUE && z + 1 >= Integer.MIN_VALUE;
  //@ requires z + x <= Integer.MAX_VALUE && z + x >= Integer.MIN_VALUE;
  //@ ensures \result == (x + 3 > 0);
  //@ assignable \nothing;
  public boolean test(int x, int y, int z) {
    ;
    y = z + 1;
    z = z + x;
    x = x + 3;
    if (z > 0) ;
    else ;
    if (x > 0) ;
    else {
      return false;
    }

    return true;
  }
}