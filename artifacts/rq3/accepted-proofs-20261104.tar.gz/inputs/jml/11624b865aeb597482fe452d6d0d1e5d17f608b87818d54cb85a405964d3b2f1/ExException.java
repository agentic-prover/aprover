public class ExException {
  //@ ensures \result == 0;
  //@ assignable \nothing;
  int zero() {
    return 0;
  }

  //@ requires secret > 0;
  //@ ensures \result == 0;
  //@ assignable \nothing;
  static int test(int secret) {
    /*@ nullable */ ExException o = null;
    if (secret > 0) {
      o = new ExException();
    } else assert false;
    int i = o.zero();
    return i;
  }
}