class TwoSum {
    //@ requires nums != null;
    //@ requires (\forall int i_q; 0 <= i_q && i_q < nums.length;
    //@     (\forall int j_q; i_q + 1 <= j_q && j_q < nums.length;
    //@         (long)nums[i_q] + (long)nums[j_q] >= Integer.MIN_VALUE && (long)nums[i_q] + (long)nums[j_q] <= Integer.MAX_VALUE));
    //@ ensures \result != null;
    //@ ensures \result.length == 2 || \result.length == 0;
    //@ ensures \result.length == 2 ==>
    //@     (0 <= \result[0] && \result[0] < \result[1] && \result[1] < nums.length &&
    //@      nums[\result[0]] + nums[\result[1]] == target);
    public int[] twoSum(int[] nums, int target) {
        int n = nums.length;
        //@ maintaining 0 <= i && i <= n;
        //@ maintaining n == nums.length;
        //@ decreases n - i;
        //@ maintaining n == nums.length;
        for (int i = 0; i < n; ++i) {
            //@ maintaining i + 1 <= j && j <= n;
            //@ decreases n - j;
            for (int j = i + 1; j < n; ++j) {
                if (nums[i] + nums[j] == target) {
                    return new int[]{i, j};
                }
            }
        }
        return new int[0];
    }
}