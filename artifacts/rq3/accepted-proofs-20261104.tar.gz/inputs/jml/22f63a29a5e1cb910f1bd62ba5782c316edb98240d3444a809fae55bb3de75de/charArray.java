public class charArray {
  //@ requires c == null || c.length >= 0;
  //@ assignable c[*];
  //@ ensures c == null ==> \result == null;
  //@ ensures c != null && c.length > 0 ==> \result != null && \result.length == c.length && \result[0] == 's';
  //@ ensures c != null && c.length == 0 ==> \result != null && \result.length == 0;
  public static /*@ nullable */ char[] f(/*@ nullable */ char c[]) {
    if (c != null && c.length > 0) {
      c[0] = 's';
    }
    return c;
  }

  //@ requires arg != null;
  //@ assignable \nothing;
  //@ ensures arg.length() != 5 ==> \result == -1;
  //@ ensures arg.length() == 5 ==> (\result == 1 || \result == 0);
  public static int fun(String arg) {
    if (arg.length() != 5) return -1;
    return 1;
  }
}