class Main {
  static /*@ spec_public */ int field;

  //@ assignable field;
  //@ ensures \result == true;
  public static boolean f() {
    int x = 3;
    Main inst = new Main();
    field = 9;
    return inst.test(x, field);
  }
  
  //@ assignable \nothing;
  //@ ensures \result == (z != 0);
  public boolean test(int x, int z) {
    ;
    int y = 3;
    x = z - y;
    if (z == 0) {
      ;
      return false;
    } else ;
    if (x == 0) ;
    else
      ;
    return true;
  }
}