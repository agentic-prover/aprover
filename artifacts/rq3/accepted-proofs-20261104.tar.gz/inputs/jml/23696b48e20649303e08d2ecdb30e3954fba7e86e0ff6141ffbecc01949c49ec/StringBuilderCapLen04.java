public class StringBuilderCapLen04 {
  //@ requires arg != null;
  //@ assignable \nothing;
  public static boolean f(String arg) {
    StringBuilder buffer = new StringBuilder(arg);
    return buffer.capacity() == 69;
  }
}