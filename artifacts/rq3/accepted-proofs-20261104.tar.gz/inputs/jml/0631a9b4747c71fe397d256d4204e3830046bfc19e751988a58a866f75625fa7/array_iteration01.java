public class array_iteration01 {

  //@ requires 0 <= index && index < 200;
  //@ ensures \result == -1 || \result == 0 || \result == 1;
  public static int f(int index) {
    int[] ia = new int[200];
    if(0 <= index && index < ia.length) return -1;
    ia[index] = Verifier.nondetInt();
    //@ maintaining 0 <= i && i <= ia.length;
    //@ decreases ia.length - i;
    for (int i = 0; i < ia.length; i++) {
      if (ia[i] == 0)
        return 0;
      ;
    }
    return 1;
  }
}