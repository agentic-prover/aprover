public final class Verifier {
  /*@ public normal_behavior
    @   ensures condition;
    @   assignable \nothing;
    @*/
  public static native void assume(boolean condition);

  /*@ public normal_behavior
    @   assignable \nothing;
    @*/
  public static native boolean nondetBoolean();

  /*@ public normal_behavior
    @   assignable \nothing;
    @*/
  public static native byte nondetByte();

  /*@ public normal_behavior
    @   assignable \nothing;
    @*/
  public static native char nondetChar();

  /*@ public normal_behavior
    @   assignable \nothing;
    @*/
  public static native short nondetShort();

  /*@ public normal_behavior
    @   assignable \nothing;
    @*/
  public static native int nondetInt();

  /*@ public normal_behavior
    @   assignable \nothing;
    @*/
  public static native long nondetLong();

  /*@ public normal_behavior
    @   assignable \nothing;
    @*/
  public static native float nondetFloat();

  /*@ public normal_behavior
    @   assignable \nothing;
    @*/
  public static native double nondetDouble();

  /*@ public normal_behavior
    @   ensures \result != null;
    @   assignable \nothing;
    @*/
  public static native String nondetString();
}
