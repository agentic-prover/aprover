public class calc {
  //@ requires a != null && b != null;
  //@ requires \invariant_for(a) && \invariant_for(b);
  //@ assignable \nothing;
  void do_stuff(String a, String b) {
    try {
      int x = Integer.parseInt(a);
      int y = Integer.parseInt(b);
      assert Integer.parseInt(a) != Integer.parseInt(b) || x == y;
    } catch (java.lang.NumberFormatException e) {
    }
  }

  //@ requires args != null;
  //@ requires args.length > 1;
  //@ requires args[0] != null;
  //@ requires args[1] != null;
  //@ requires \invariant_for(args[0]) && \invariant_for(args[1]);
  //@ assignable \nothing;
  public static void fun(String[] args) {
    if (args.length < 2) {
      ;
      return;
    }
    new calc().do_stuff(args[0], args[1]);
  }
}