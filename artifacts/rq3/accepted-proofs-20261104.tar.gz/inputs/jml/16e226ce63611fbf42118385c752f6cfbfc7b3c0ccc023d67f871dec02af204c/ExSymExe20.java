class Main {
  static /*@ spec_public */ int field;
  static /*@ spec_public */ int field2;

  //@ assignable field;
  //@ ensures \result == true || \result == false;
  public static boolean main() {
    int x = 3;
    Main inst = new Main();
    field = 9;
    return inst.test(x, field, field2);
  }

  //@ requires x + z <= Integer.MAX_VALUE && x + z >= Integer.MIN_VALUE;
  //@ requires z - 3 <= Integer.MAX_VALUE && z - 3 >= Integer.MIN_VALUE;
  //@ assignable \nothing;
  public boolean test(int x, int z, int r) {
    ;
    int y = 3;
    r = x + z;
    x = z - y;
    z = r;
    if (z >= x) ;
    else ;
    if (x >= r) {
      return false;
    } else ;

    return true;
  }
}