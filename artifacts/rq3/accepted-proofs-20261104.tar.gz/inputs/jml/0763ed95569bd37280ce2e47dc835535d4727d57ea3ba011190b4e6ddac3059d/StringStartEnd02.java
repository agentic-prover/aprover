public class StringStartEnd02 {

  //@ requires args != null;
  //@ requires args.length >= 0;
  //@ requires (\forall int k; 0 <= k && k < args.length; args[k] != null);
  //@ requires (\forall int k; 0 <= k && k < args.length; args[k].length() >= 0);
  //@ requires (\forall int k; 0 <= k && k < args.length; \invariant_for(args[k]));
  //@ assignable \nothing;
  //@ ensures args.length < 4 ==> \result == false;
  public static boolean f(String[] args) {
    if (args.length < 4)
      return false;
    int i = 0;

    //@ maintaining 0 <= j && j <= 4;
    //@ maintaining j <= args.length;
    //@ maintaining 0 <= i && i <= j;
    //@ decreases 4 - j;
    for (int j = 0; j < 4; j++) {
      if (args[j].startsWith("te"))
        ++i;
    }

    return i == 1;
  }
  
}