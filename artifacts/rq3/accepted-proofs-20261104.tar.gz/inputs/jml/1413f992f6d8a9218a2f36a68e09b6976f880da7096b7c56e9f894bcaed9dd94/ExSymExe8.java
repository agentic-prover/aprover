class Main {
  //@ assignable \nothing;
  public boolean test(int x, int z) {
    ;
    int y = 3;
    int p = 2;
    x = z - y;
    z = z - p;
    if (z < 0) {
      ;
      return false;
    } else ;
    if (x < 0) ;
    else
      ;
    return true;
  }
}