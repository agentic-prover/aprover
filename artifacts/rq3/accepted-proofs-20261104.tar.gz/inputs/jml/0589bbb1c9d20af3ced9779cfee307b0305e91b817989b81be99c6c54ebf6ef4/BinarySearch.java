public class BinarySearch {

    //@ requires arr != null;
    //@ assignable \nothing;
    //@ ensures \result == -1 || (0 <= \result && \result < arr.length && arr[\result] == key);
    public static int Binary(int[] arr, int key) {
        if (arr.length == 0) {
            return -1;
        } else {
            int low = 0;
            int high = arr.length;
            int mid =  high / 2;

            //@ maintaining 0 <= low && low <= high && high <= arr.length;
            //@ maintaining low <= mid && mid <= high;
            //@ maintaining low + (high - low) / 2 == mid || (low >= high);
            //@ decreases high - low;
            while (low < high && arr[mid] != key) {
                if (arr[mid] < key) {
                    low = mid + 1;
                } else {
                    high = mid;
                }
                mid = low + (high - low) / 2;
            }
            if (low >= high) {
                return -1;
            }
            return mid;
        }
    }
}