class Main {
  static /*@ spec_public */ int field;

  //@ assignable field;
  //@ ensures \result == true || \result == false;
  public static boolean f() {
    int x = 3;
    Main inst = new Main();
    field = 9;
    return inst.test2(0.0);
  }

  //@ assignable \nothing;
  public boolean test2(double in) {
    if (Math.round(in) > 16.0) {
      return false;
    } else
      ;
    return true;
  }

  //@ assignable \nothing;
  public void angleXY_(double x1, double y1) {
    double x = x1;
    double y = y1;
    if (x == 0 && y != 0) {
      ;
    } else {
      ;
      if (x < 0) {
        ;
      } else if (x > 0) {
        ;
      }
    }
  }
}