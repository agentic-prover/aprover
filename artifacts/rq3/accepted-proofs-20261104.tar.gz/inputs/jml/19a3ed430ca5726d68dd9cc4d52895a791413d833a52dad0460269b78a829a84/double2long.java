public class double2long {

  //@ requires l < 100L && l > -100L;
  //@ assignable \nothing;
  public static double bar(long l) {
    assert l < 100L && l > -100L;
    return (double) l;
  }

  //@ requires (x < 0.0 && x * 10.0 > -100.0 && x * 10.0 < 100.0) || (x >= 0.0 && x / 10.0 > -100.0 && x / 10.0 < 100.0);
  //@ requires (x < 0.0 && (long)(x * 10.0) < 100L && (long)(x * 10.0) > -100L) || (x >= 0.0 && (long)(x / 10.0) < 100L && (long)(x / 10.0) > -100L);
  //@ assignable \nothing;
  public static double foo(double x) {
    if (x < 0.0) {
      x *= 10.0;
    } else {
      x /= 10.0;
    }
    long l = (long) x;
    return bar(l);
  }

}