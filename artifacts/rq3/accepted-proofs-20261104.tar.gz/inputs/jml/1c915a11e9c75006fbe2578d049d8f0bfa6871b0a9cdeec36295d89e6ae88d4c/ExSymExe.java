class Main {

  static /*@ spec_public */ int field;

  //@ requires a != null && a.length >= 2;
  //@ assignable \nothing;
  //@ requires a != null && a.length > 1;
  public void testa(int b, boolean[] a) {
    b++;
    if (a[0]) ;
    if (a[1]) ;
  }

  //@ assignable \nothing;
  public void test5(double xm, double ym) {
    if (xm < ym && xm > ym) {
      ;
      assert (false);
    } else assert (true);
  }

  //@ assignable \nothing;
  public void test3(double x, double y) {
    if (Math.sin(x) + Math.cos(y) == 1) ;
    else ;
  }

  //@ requires x > 0 && y > 0 ==> (long)y + (long)x <= Integer.MAX_VALUE && (long)y + (long)x >= Integer.MIN_VALUE;
  //@ requires !(x > 0 && y > 0) ==> (long)y - (long)x <= Integer.MAX_VALUE && (long)y - (long)x >= Integer.MIN_VALUE;
  //@ ensures x > 0 && y > 0 ==> \result == y + x;
  //@ ensures !(x > 0 && y > 0) ==> \result == y - x;
  //@ assignable \nothing;
  public static int test4(int x, int y) {
    if (x > 0 && y > 0) {
      return y + x;
    } else {
      return y - x;
    }
  }

  //@ assignable \nothing;
  public static void test1(int x, boolean b) {
    ;
    Integer z = new Integer((int) x);
    if (z <= 1200) ;
    if (z >= 1200) ;
    if (b) {
      ;
    } else {
      ;
    }
  }

  //@ requires x != 0;
  //@ requires (long)x + (long)z <= Integer.MAX_VALUE && (long)x + (long)z >= Integer.MIN_VALUE;
  //@ requires x + z <= z;
  //@ assignable \nothing;
  public void test(int x, int z) {
    // x = x >>> 1;
    x = x + z;
    if (x > z) {
      // if (z > x)
      ;
      assert false;
    }
    if (x + 6 > 0) ;
    else ;
  }

  //@ requires z != 0;
  //@ requires z < Integer.MAX_VALUE;
  //@ assignable \nothing;
  public void test2(int x, int z) {
    ;
    x = z++;
    // z=5;
    if (z > 0) {
      ;
    } else ;
    if (x > 0) ;
    else ;
  }
}