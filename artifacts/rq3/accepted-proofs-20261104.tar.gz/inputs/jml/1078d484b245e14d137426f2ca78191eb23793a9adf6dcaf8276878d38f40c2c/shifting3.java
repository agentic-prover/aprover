public class shifting3 {

  //@ requires i >= 1 && i <= 63;
  //@ ensures i < 1 || i > 100 ==> \result == -1;
  //@ ensures i >= 1 && i <= 100 ==> \result == 1;
  //@ ensures \result == 0 || \result == 1 || \result == -1;
  //@ assignable \nothing;
  public static int f(int i) {
    if (i < 1 || i > 100) {
      return -1;
    }

    return ((1L << i) != 1L) ? 1 : 0;
  }
}