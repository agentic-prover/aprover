class PassPillowBranch {
    //@ requires n >= 2;
    //@ requires time >= 0;
    //@ requires (n - 1) <= Integer.MAX_VALUE / 2;
    //@ requires (long)(n - 1) * 2 <= Integer.MAX_VALUE;
    //@ requires n * 2 <= Integer.MAX_VALUE;
    //@ ensures 1 <= \result && \result <= n;
    public int passPillow(int n, int time) {
        time = time % (n - 1) * 2;
        if (time < n) {
            return time + 1;
        }
        return n * 2 - time - 1;
    }
}