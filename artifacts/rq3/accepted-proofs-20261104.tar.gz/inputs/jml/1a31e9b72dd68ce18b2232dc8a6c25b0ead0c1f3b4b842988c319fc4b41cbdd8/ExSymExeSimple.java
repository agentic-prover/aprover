class Main {
  static class Node {

    //@ ensures \result == (a <= b);
    //@ assignable \nothing;
    public boolean test(int a, int b) {

      if (a > b) {
        return false;
      } else if (a == b) ;
      else
        ;
      return true;
    }
  }

  //@ ensures \result == true;
  //@ assignable \nothing;
  public static boolean f(int arg) {
    if (arg >= Integer.MAX_VALUE) return true;
    Main inst = new Main();
    Node n = new Node();
    return n.test(arg, arg + 1);
  }
}