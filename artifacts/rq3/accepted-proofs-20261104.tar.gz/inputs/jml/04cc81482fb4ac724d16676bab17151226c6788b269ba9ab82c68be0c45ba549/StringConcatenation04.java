public class StringConcatenation04 {
  //@ requires s1 != null;
  //@ assignable \nothing;
  public static boolean f(String s1){
    String tmp = s1;
    return tmp.equals("Happy  at");
  }
}