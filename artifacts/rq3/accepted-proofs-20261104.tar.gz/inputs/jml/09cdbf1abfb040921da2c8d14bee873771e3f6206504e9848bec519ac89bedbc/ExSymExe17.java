class Main {
  static /*@ spec_public */ int field;

  //@ assignable field;
  public static boolean f() {
    int x = 3;
    Main inst = new Main();
    field = 9;
    return inst.test(x, field);
  }

  //@ assignable \nothing;
  //@ ensures \result == (x - 4 != 0);
  public boolean test(int x, int z) {
    ;
    int y = 0;
    z = x - y - 4;
    if (z == 0) {
      ;
      return false;
    } else ;
    if (y == 0) ;
    else
      ;
    return true;
  }
}