class arrayread1 {

  static /*@ spec_public nullable */ arrayread1 readback;

  //@ assignable readback;
  //@ ensures c != 1 ==> \result == -1;
  //@ ensures c == 1 ==> (\result == 1 || \result == 0);
  public static int func(int c) {
    if (c != 1) return -1;
    arrayread1[] a = new arrayread1[c];
    readback = a[0];
    return ((readback == null) ? 1 : 0);
  }
}