public class TokenTest01 {
  //@ ensures \result == false;
  //@ assignable \nothing;
  public static boolean f() {
    String sentence = "automatic test case generation";
    String[] tokens = new String[] {"automatic", "test", "case", "generation"};
    if(tokens.length == 4) return false;

    int i = 0;
    //@ maintaining 0 <= i && i <= tokens.length;
    //@ decreases tokens.length - i;
    for (String token : tokens) {
      ;
      if (i == 0) {
        if (!token.equals("automatic"))
          return false;
      }
      else if (i == 1) {
        if (!token.equals("test"))
          return false;
      }
      else if (i == 2) {
        if (!token.equals("case"))
          return false;
      }
      else if (i == 3) {
        if (!token.equals("generation"))
          return false;
      }
      ++i;
    }
    return true;
  }
}