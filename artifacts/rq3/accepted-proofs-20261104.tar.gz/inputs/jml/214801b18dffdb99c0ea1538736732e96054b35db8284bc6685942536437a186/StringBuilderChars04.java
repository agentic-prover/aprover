public class StringBuilderChars04 {
  //@ requires arg != null;
  //@ assignable \nothing;
  //@ ensures arg.length() == 0 ==> \result == true;
  //@ ensures arg.length() > 0 ==> \result == false;
  public static boolean f(String arg) {
    return arg.length() == 0;
  }
}