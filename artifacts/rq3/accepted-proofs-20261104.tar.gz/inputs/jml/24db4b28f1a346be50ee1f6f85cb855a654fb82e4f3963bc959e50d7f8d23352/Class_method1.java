public class Class_method1 {
  public static boolean fun() {
    return f(String.class, true);
  }

  //@ requires c != null;
  //@ assignable \nothing;
  //@ ensures \result == b;
  public static boolean f(/*@ nullable */ Class c, boolean b) {
    return b;
  }
}