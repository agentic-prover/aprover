import java.util.HashSet;
import java.util.Set;

class RepeatedChar {
    //@ requires s != null;
    //@ requires (\exists int i_q; 0 <= i_q && i_q < s.length();
    //@     (\exists int j; 0 <= j && j < i_q; s.charAt(j) == s.charAt(i_q)));
    //@ assignable \nothing;
    public char repeatedCharacter(String s) {
        //@ nullable
        Set<Character> seen = new HashSet<Character>();

        //@ maintaining 0 <= i && i <= s.length();
        //@ decreases s.length() - i;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (!seen.add(ch)) {
                return ch;
            }
        }
        // impossible
        return ' ';
    }
}