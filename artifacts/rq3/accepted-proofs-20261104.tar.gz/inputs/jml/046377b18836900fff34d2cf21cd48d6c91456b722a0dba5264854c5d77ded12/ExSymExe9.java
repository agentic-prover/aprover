class Main {
  static /*@ spec_public */ int field;

  //@ assignable field;
  public static boolean f() {
    int x = 3; 
    Main inst = new Main();
    field = 9;
    return inst.test(x, field);
  }

  //@ assignable \nothing;
  public boolean test(int x, int z) {
    ;
    int y = 3;
    z = x - y - 4;
    if (z < 0) ;
    else {
      ;
      return false;
    }
    if (y < 0) ;
    else ;

    return true;
  }
}