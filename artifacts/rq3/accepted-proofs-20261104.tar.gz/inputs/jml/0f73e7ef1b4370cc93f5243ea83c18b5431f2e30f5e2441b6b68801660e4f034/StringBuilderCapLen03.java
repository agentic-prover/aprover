public class StringBuilderCapLen03 {
  //@ requires arg != null;
  //@ assignable \nothing;
  //@ ensures \result == (arg.length() == 51);
  public static boolean f(String arg) {
    String buffer = arg;
    return arg.length() == 51;
  }
}