class ComputeOverlap {
    //@ requires ax1 <= ax2 && ay1 <= ay2;
    //@ requires bx1 <= bx2 && by1 <= by2;
    //@ requires (long)(ax2 - ax1) * (ay2 - ay1) <= Integer.MAX_VALUE;
    //@ requires (long)(bx2 - bx1) * (by2 - by1) <= Integer.MAX_VALUE;
    //@ requires ax2 - ax1 >= 0 && ay2 - ay1 >= 0;
    //@ requires bx2 - bx1 >= 0 && by2 - by1 >= 0;
    //@ requires (long)(ax2 - ax1) * (ay2 - ay1) >= Integer.MIN_VALUE;
    //@ requires (long)(bx2 - bx1) * (by2 - by1) >= Integer.MIN_VALUE;
    //@ assignable \nothing;
    public int computeOverlapArea(int ax1, int ay1, int ax2, int ay2, int bx1, int by1, int bx2, int by2) {
        int area1 = (ax2 - ax1) * (ay2 - ay1), area2 = (bx2 - bx1) * (by2 - by1);
        int overlapWidth = (ax2<bx2?ax2:bx2) - (ax1>bx1?ax1:bx1), overlapHeight = (ay2<by2?ay2:by2) - (ay1>by1?ay1:by1);
        int overlapArea = (overlapWidth>0?overlapWidth:0) * (overlapHeight>0?overlapHeight:0);
        return overlapArea;
    }
}