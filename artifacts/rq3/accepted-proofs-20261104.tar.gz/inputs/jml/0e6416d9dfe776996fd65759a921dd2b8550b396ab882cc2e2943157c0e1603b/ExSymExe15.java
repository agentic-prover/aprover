class Main {
  static /*@ spec_public */ int field;
  static /*@ spec_public */ int field2;

  //@ requires arg != null;
  //@ requires (int) arg >= Short.MIN_VALUE && (int) arg <= Short.MAX_VALUE;
  //@ assignable field;
  public static boolean f(Short arg) {
    int x = 13000;
    Main inst = new Main();
    field = arg;
    if (field < 0)
      return true;
    return inst.test(x, field, field2);
  }
  
  //@ requires x + z >= Integer.MIN_VALUE && x + z <= Integer.MAX_VALUE;
  //@ assignable \nothing;
  public boolean test(int x, int z, int r) {
    ;
    int y = 3;
    r = x + z;
    z = x - y - 4;
    if (r <= 99) {
      ;
      return false;
    } else ;
    if (x <= z) ;
    else ;
    return true;
  }
}