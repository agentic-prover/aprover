class Main {
  static /*@ spec_public */ int field;
  static /*@ spec_public */ int field2;

  //@ assignable field;
  //@ ensures \result == true || \result == false;
  public static boolean f() {
    int x = 3;
    Main inst = new Main();
    field = 9;
    return inst.test(x, field, field2);
  }

  //@ assignable \nothing;
  //@ ensures \result == true || \result == false;
  public boolean test(int x, int z, int r) {
    ;
    int y = 3;
    x = x * r;
    z = z * x;
    r = y * x;
    if (z > x) {
      ;
      return false;
    } else ;
    if (x > r) ;
    else ;
    return true;
  }
}