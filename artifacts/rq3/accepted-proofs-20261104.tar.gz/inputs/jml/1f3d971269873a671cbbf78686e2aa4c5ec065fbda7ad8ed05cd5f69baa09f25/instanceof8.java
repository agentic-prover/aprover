class Main {
  //@ requires true;
  //@ ensures i != null ==> \result == true;
  //@ ensures i == null ==> \result == false;
  //@ assignable \nothing;
  public static boolean test(/*@ nullable */ Integer i) {
    if (i instanceof Integer) {
      return true;
    } else {
      return false;
    }
  }

  //@ ensures \result == true;
  //@ assignable \nothing;
  public static boolean f() {
    return (!test(null)) && (test(new Integer(1)));
  }
}