class cl {}

interface A {
  /*@
    @ requires false;
    @ assignable \nothing;
    @ ensures true;
    @*/
  public void f();
}

class B implements A {
  /*@
    @ requires false;
    @ assignable \nothing;
    @ ensures true;
    @*/
  public void f() {
    assert false; // should fail
  }
}

class C implements A {
  /*@
    @ requires false;
    @ assignable \nothing;
    @ ensures true;
    @*/
  public void f() {}
}

class Main {
  /*@
    @ requires false;
    @ assignable \nothing;
    @ ensures true;
    @*/
  public static void main(String[] args) {
    A b = new B();
    A c = new C();
    b.f(); // really calls B.f
  }
}