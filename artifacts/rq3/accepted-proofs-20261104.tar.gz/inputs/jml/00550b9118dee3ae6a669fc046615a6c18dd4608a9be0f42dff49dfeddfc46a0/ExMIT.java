import java.util.Random;

public class ExMIT {
  public static void main(String[] args) {
    if (new Random().nextInt() == 1) foo(0);
  }

  //@ requires i > Integer.MIN_VALUE;
  //@ requires i < Integer.MAX_VALUE;
  //@ requires i >= -1073741824 && i <= 1073741823;
  //@ requires 2 * (i + 1) != 10;
  //@ ensures \result == 0;
  //@ assignable \nothing;
  public static int foo(int i) {
    if (2 * (i + 1) == 10) {
      assert false;
      return 1;
    }
    return 0;
  }

  //@ ensures (i + 1) * 2 > 10 ==> \result == 1;
  //@ ensures (i + 1) * 2 <= 10 ==> \result == 0;
  //@ assignable \nothing;
  public static int boo(float i) {
    if ((i + 1) * 2 > 10) return 1;
    return 0;
  }
}