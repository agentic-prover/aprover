class PowerOfFour {
    //@ requires n != Integer.MIN_VALUE;
    //@ assignable \nothing;
    //@ ensures \result <==> (n > 0 && (n & (n - 1)) == 0 && (n & 0xaaaaaaaa) == 0);
    public boolean isPowerOfFour(int n) {
        return n > 0 && (n & (n - 1)) == 0 && (n & 0xaaaaaaaa) == 0;
    }
}