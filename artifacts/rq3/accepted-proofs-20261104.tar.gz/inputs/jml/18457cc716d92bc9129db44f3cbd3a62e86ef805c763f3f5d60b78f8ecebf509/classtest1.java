public class classtest1 {
  //@ requires args != null;
  public static void main(String[] args) {
    g(classtest1.class);
  }

  //@ requires c != null;
  //@ assignable \nothing;
  static void g(Object c) {
    assert true;
  }
}