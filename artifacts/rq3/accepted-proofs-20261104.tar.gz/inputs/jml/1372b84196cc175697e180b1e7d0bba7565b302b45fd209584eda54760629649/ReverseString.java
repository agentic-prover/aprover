class ReverseString {
    //@ requires s != null;
    //@ assignable s[*];
    //@ ensures s.length == \old(s.length);
    public void reverseString(char[] s) {
        int n = s.length;
        //@ maintaining 0 <= left && left <= right + 1 && right == n - 1 - left + (left <= right ? 0 : 0);
        //@ maintaining left + right == n - 1;
        //@ maintaining 0 <= left && right == n - 1 - left;
        //@ maintaining left <= right + 1;
        //@ decreases right - left;
        for (int left = 0, right = n - 1; left < right; ++left, --right) {
            char tmp = s[left];
            s[left] = s[right];
            s[right] = tmp;
        }
    }
}