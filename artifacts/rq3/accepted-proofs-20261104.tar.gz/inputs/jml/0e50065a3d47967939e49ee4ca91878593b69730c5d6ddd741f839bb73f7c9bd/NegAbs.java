public class NegAbs {
	
	//@ requires num != Integer.MIN_VALUE;
	//@ ensures \result <= 0;
	//@ ensures \result == -num || \result == num;
	//@ ensures num < 0 ==> \result == num;
	//@ ensures num >= 0 ==> \result == -num;
	//@ assignable \nothing;
	public int negAbs(int num) {
		if (num < 0)
			return num;
		else
			return -num;
	}

}