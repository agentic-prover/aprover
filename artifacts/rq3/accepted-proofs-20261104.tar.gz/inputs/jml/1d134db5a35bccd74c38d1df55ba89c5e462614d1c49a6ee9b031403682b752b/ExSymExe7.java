class Main {
  //@ ensures \result == (x - 3 - 4 != 0);
  public boolean test(int x, int z) {
    ;
    int y = 3;
    z = x - y - 4;
    if (z != 0) ;
    else {
      ;
      return false;
    }
    if (y != 0) ;
    else
      ;
    return true;
  }
}