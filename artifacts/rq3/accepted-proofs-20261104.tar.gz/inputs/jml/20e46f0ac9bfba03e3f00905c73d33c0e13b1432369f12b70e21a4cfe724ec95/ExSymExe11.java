class Main {
  //@ spec_public
  static int field;

  //@ ensures arg < 0 ==> \result == true;
  //@ ensures arg >= 0 ==> \result == true;
  //@ assignable field;
  public static boolean f(int arg) {
    if (arg < 0)
      return true;
    int x = 3;
    Main inst = new Main();
    field = arg % 100;
    return inst.test(x, field);
  }
  
  //@ assignable \nothing;
  //@ ensures \result == true;
  public boolean test(int x, int z) {
    ;
    int y = 3;
    z = -x;
    x = z * x;
    if (z <= 0) ;
    else ;
    if (y <= 0) {
      ;
      return false;
    } else ;
    return true;
  }
}