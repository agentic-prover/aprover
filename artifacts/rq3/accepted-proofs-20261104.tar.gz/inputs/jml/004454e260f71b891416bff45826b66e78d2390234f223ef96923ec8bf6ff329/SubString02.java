public class SubString02 {
  //@ requires letters != null;
  //@ requires letters.length() >= 38;
  //@ assignable \nothing;
  public static boolean f(String letters) {
    String tmp = letters.substring(20);
    return tmp.equals("erationatdifffblue");
  }
}