public class ReLU {
    //@ ensures x >= 0 ==> \result == x;
    //@ ensures x < 0 ==> \result == 0.0;
    //@ assignable \nothing;
    public static double computeReLU(double x) {
        if(x >= 0) {
            return x;
        }
        return 0.0;
    }
}