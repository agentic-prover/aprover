class Main {

  //@ ensures \result == true;
  //@ assignable \nothing;
  public static boolean f() {
    int a = 3;
    Main inst = new Main();
    int b = 8;
    return inst.test(a, b, a);
  }

  /*
   * test concrete = symbolic
   * (con#sym#sym)
   */
  //@ requires z + z <= Integer.MAX_VALUE;
  //@ requires z + z >= Integer.MIN_VALUE;
  //@ ensures \result == (z < z + z);
  //@ assignable \nothing;
  public boolean test(int x, int y, int z) {
    ;
    x = z;
    y = z + x;
    if (x < y) ;
    else {
      return false;
    }
    if (z > 0) ;
    else ;

    return true;
  }
}