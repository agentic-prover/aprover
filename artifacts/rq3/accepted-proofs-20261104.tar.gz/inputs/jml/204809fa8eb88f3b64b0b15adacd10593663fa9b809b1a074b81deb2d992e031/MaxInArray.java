class MaxInArray {
    //@ requires a != null;
    //@ ensures a.length == 0 ==> \result == -1;
    //@ ensures a.length > 0 ==> (\forall int i_q; 0 <= i_q && i_q < a.length; a[i_q] <= \result);
    //@ assignable \nothing;
    public int maxElementInArray(int[] a) {
        if (a.length == 0) return -1;
        int res = Integer.MIN_VALUE;
        //@ maintaining 0 <= i && i <= a.length;
        //@ maintaining (\forall int k; 0 <= k && k < i; a[k] <= res);
        //@ decreases a.length - i;
        for(int i = 0; i < a.length; i++) {
            res = ((a[i] > res) ? a[i] : res);
        }
        return res;
    }
}