class FindClosestNum {

    //@ requires nums != null && nums.length > 0;
    public int findClosestNumber(int[] nums) {
        int ans = Integer.MAX_VALUE;

        //@ maintaining 0 <= i && i <= nums.length;
        //@ maintaining ans == Integer.MAX_VALUE || (\exists int k; 0 <= k && k < i; nums[k] == ans);
        //@ decreases nums.length - i;
        for(int i = 0; i < nums.length; i++) {
            int num = nums[i];
            int absNum = (num<0?-num:num);
            int absAns = (ans<0?-ans:ans);
            if(absNum < absAns || (absNum == absAns && num > ans)) {
                ans = num;
            }
        }

        return ans;
    }
}