public class ChangeCase {

  //@ assignable \nothing;
  //@ ensures c > 'z' ==> \result == c;
  //@ ensures c >= 'a' && c <= 'z' ==> \result == (char)(c - 'a' + 'A');
  //@ ensures c > 'Z' && c < 'a' ==> \result == c;
  //@ ensures c >= 'A' && c <= 'Z' ==> \result == (char)(c - 'A' + 'a');
  //@ ensures c < 'A' ==> \result == c;
  public char changeCase(char c) {
    char result = ' ';    
    if (c > 'z') {
      result = c;
    } else if (c >= 'a') {
      result =  (char)(c - 'a' + 'A');
    } else if (c > 'Z') {
      result =  c;
    } else if (c >= 'A') {
      result =  (char)(c - 'A' + 'a');
    } else {
      result = c;
    }
    return result;
  }

}