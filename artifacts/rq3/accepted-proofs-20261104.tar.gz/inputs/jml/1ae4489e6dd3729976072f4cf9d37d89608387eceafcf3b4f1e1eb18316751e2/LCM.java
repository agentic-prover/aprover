public class LCM {
    
    //@ requires num1 != Integer.MIN_VALUE && num2 != Integer.MIN_VALUE;
    //@ assignable \nothing;
    //@ ensures (num1 == 0 || num2 == 0) ==> \result == -1;
    //@ ensures (num1 != 0 && num2 != 0) ==> (\result == -1 || (\result > 0 && \result % (num1 < 0 ? -num1 : num1) == 0 && \result % (num2 < 0 ? -num2 : num2) == 0));
    public static int lcm(int num1, int num2) 
    {
        if (num1 == 0 || num2 == 0) {
            return -1;
        }	
        if (num1 < 0)
            num1 = -num1;
        if (num2 < 0)
            num2 = -num2;

            int result = (num1 > num2) ? num1 : num2;

            //@ maintaining result >= 1;
            //@ maintaining num1 >= 1 && num2 >= 1;
            //@ maintaining result <= Integer.MAX_VALUE;
            //@ decreases Integer.MAX_VALUE - result;
            while (result < Integer.MAX_VALUE)
            {
                if (result % num1 == 0 && result % num2 == 0)
                {
                    break;
                }
                result++;
            }

        if (result % num1 == 0 && result % num2 == 0) {
            return result;
        }
        return -1;
    }

}