class Main {
  static /*@ spec_public */ int field;
  static /*@ spec_public */ int field2;

  //@ requires arg != null;
  //@ assignable field;
  //@ ensures arg < 0 ==> \result == true;
  public static boolean f(Short arg) {
    if (arg < 0)
      return true;
    int x = arg;

    Main inst = new Main();
    field = arg;
    return inst.test(x, arg, field2);
  }
  
  //@ assignable \nothing;
  public boolean test(int x, int z, int r) {
    ;
    int y = 3;
    r = x + z;
    x = z - y;
    z = r;
    if (z <= x) {
      ;
      return false;
    } else ;
    if (x <= r) ;
    else ;

    return true;
  }
}