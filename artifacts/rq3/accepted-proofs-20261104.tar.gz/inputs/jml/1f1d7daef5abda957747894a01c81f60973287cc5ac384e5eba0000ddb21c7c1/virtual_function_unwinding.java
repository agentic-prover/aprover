interface Interface {
  //@ ensures true;
  //@ assignable \nothing;
  boolean b();
}

class Inner implements Interface {
  //@ ensures \result == false;
  //@ assignable \nothing;
  public boolean b() {
    return false;
  }
}

class Outer implements Interface {
  private /*@ spec_public nullable @*/ Interface inner;

  //@ public invariant inner != null;

  //@ requires inner != null;
  //@ ensures this.inner == inner;
  public Outer(Interface inner) {
    this.inner = inner;
  }

  //@ assignable \nothing;
  public boolean b() {
    return !inner.b();
  }
}

public class virtual_function_unwinding {
  public static boolean fun(String[] args) {
    return new Outer(new Inner()).b();
  }
}