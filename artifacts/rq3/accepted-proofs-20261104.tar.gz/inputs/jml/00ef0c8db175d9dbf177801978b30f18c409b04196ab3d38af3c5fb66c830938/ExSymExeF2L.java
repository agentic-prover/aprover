class Main {

  //@ ensures \result == true || \result == false;
  public static boolean f(float x) {
    if (x >= 0.0f && x <= Long.MAX_VALUE / 2) {
      Main inst = new Main();
      return inst.test(x);
    }
    return true;
  }

  //@ ensures \result == true || \result == false;
  public boolean test(float x) {

    long res = (long) ++x;
    if (res > 0) ;
    else {
      return false;
    }
    return true;
  }
}