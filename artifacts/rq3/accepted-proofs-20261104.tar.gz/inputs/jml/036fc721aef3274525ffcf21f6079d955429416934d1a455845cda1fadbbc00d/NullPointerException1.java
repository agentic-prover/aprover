class NullPointerException1 {
  //@ assignable \nothing;
  //@ ensures \result == true;
  public static boolean f() {
    /*@ nullable */ Object o = null;
    try {
      o.hashCode();
      // should pass
      return false;
    } catch (Exception e) {
    }
    return true;
  }
}
;