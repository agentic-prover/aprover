class A extends RuntimeException {}

class B extends A {}

public class exception18 {
  //@ ensures false;
  //@ assignable \nothing;
  //@ signals (A a) !(a instanceof B);
  //@ signals_only A;
  private static void foo() {
    A a = new A();
    throw a;
  }

  //@ assignable \nothing;
  //@ signals_only java.lang.RuntimeException;
  public static void main(String[] args) {
    try {
      foo();
      //@ unreachable;
      assert false;
    } catch (B e) {
      assert false;
    } catch (A e) {
      // expected here
    }
  }
}