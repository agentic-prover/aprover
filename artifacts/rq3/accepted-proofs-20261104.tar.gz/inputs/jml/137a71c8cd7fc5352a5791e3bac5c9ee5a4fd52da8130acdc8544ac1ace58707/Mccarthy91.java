public class Mccarthy91 {
  //@ ensures n > 100 ==> \result == n - 10;
  //@ ensures n <= 100 ==> \result == 91;
  //@ assignable \nothing;
  //@ measured_by 101 - n;
  public static int f(int n) {
    if (n > 100) return n - 10;
    else return f(f(n + 11));
  }
}