#include <assert.h>

int unknown1();
int unknown2();
int unknown3();
int unknown4();

/*
 * Taken from "Counterexample Driven Refinement for Abstract Interpretation" (TACAS'06) by Gulavani
 */
/*@
requires n > 0;
*/
void foo(int n) {
  int x = 0;
  int m = 0;
  // invariant (0 <= x && x <= n)
  // invariant (0 == x || m < x)
  /*@
  loop invariant 0 <= x;
  loop invariant x <= n;
  loop invariant 0 <= m;
  loop invariant (m < x) || (x == 0);
  loop invariant m >= 0;
  loop invariant m <= x;
  loop assigns m, x;
*/
while (x < n) {
    if (unknown1()) {
      m = x;
    }
    x = x + 1;
  }
  if (n > 0) {
    /*@ assert 0 <= m && m < n; */
  }
}