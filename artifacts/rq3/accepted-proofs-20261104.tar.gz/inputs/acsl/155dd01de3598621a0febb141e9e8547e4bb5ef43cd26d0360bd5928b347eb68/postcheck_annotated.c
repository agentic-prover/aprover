#include <assert.h>
int unknown1();

/*
 * "nest-if8" from InvGen benchmark suite
 */

void main() {
  int i, j, k, n, m;
  if (m + 1 < n);
  else return;
  // invariant (0 <= i && i <= n + 3)
  /*@
  loop invariant 0 <= i;
  loop assigns i, j, k;
*/
for (i = 0; i < n; i += 4) {
    // invariant (i <= j && j <= m + 1)
    /*@
  loop invariant i <= j;
  loop invariant i >= 0;
  loop invariant j >= 0;
  loop invariant n + j + 5 > i;
  loop assigns j, k;
*/
for (j = i; j < m;) {
      if (unknown1()) {
        /*@ assert j >= 0; */
        j++;
        k = 0;
        /*@
  loop invariant 0 <= k;
  loop invariant k <= j;
  loop assigns k;
*/
while (k < j) {
          k++;
        }
      } else {
        /*@ assert n + j + 5 > i; */
        j += 2;
      }
    }
  }
}