#include "assert.h"

void main() {
  int A[2048];
  int i;

  // invariant (forall i: 0 <= i && i < 1024 => A[i] == i)
  /*@
  loop invariant 0 <= i;
  loop invariant i <= 1024;
  loop invariant \forall integer k; (0 <= k < i) ==> (A[k] == k);
  loop assigns i, A[..];
*/
for (i = 0; i < 1024; i++) {
    A[i] = i;
  }

  /*@ assert A[1023] == 1023; */
}