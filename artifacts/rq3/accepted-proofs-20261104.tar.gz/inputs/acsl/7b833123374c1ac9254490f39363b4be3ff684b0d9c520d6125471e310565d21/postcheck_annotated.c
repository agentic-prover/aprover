/*@
requires n > 1;
*/
void foo(int n)
{
    int x = 1;
    int m = 1;

    /*@
  loop invariant 1 <= x;
  loop invariant x <= n;
  loop invariant 1 <= m;
  loop invariant (m < x) || (m == 1);
  loop invariant (m <= x - 1) || (m == 1);
  loop invariant (m < n) || (n <= 1);
  loop invariant (m == 1) || (m < x);
  loop invariant (m < n) || (n <= 1);
  loop invariant (m <= n - 1) || (n <= 1);
  loop invariant (m < x) || (x == 1);
  loop invariant (m == 1) || (m <= x - 1);
  loop invariant (n <= 1) || (m <= n - 1);
  loop assigns m, x;
*/
while (x < n) {
        if (unknown()) {
            m = x;
        }
        x = x + 1;
    }

    //post-condition
    if(n > 1) {
       // @ assert m < n;
       //// @ assert m >= 1;
    }
}
