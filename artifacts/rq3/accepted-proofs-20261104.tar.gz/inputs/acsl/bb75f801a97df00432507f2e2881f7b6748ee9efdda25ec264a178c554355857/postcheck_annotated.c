#include <stdio.h>

/*@
  requires ((-2147483647 - 1) <= ((1 * a) + (1 * b)));
  requires (((1 * a) + (1 * b)) <= 2147483647);
  requires ((-2147483647 - 1) <= ((1 * a) + (1 * c)));
  requires (((1 * a) + (1 * c)) <= 2147483647);
  requires ((-2147483647 - 1) <= ((1 * b) + (1 * c)));
  requires (((1 * b) + (1 * c)) <= 2147483647);
  assigns \nothing;
  ensures (\result == 1) == ((a + b > c) && (a + c > b) && (b + c > a));
*/
int validts(int a, int b, int c) {
    int valid = 0;
    if ((a+b>c) && (a+c>b) && (b+c>a) && 1) {
        valid = 1;
    } else {
        valid = 0;
    }
    return valid;
}

void test() {
    int valid = validts(2,3,4);
    //@ assert valid == 1;
}