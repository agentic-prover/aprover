#include <assert.h>
int unknown1();
int unknown2();
int unknown3();
int unknown4();

/*
 * from Invgen test suite
 */
/*@
requires n > 0;
requires k > n;
*/
int foo(int n, int k) {

  int i, j;

  j = 0;
  // invariant (j <= n && j + k > n)
  /*@
  loop invariant 0 <= j;
  loop invariant j <= n;
  loop invariant j + k == n + (k - (n - j));
  loop invariant j + k > n - 1;
  loop invariant j + k >= n;
  loop assigns j, k;
*/
while( j < n ) {
    j++;
    k--;
  } 
  /*@ assert k>=0; */
  return 0;
}
