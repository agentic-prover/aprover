void foo(int y) {
  int x = 1;
  
  /*@
  loop invariant x >= 1;
  loop assigns x;
*/
while (x < y) {
    x = x + x;
  }
  // post-condition
  /*@ assert x >= 1; */
}
