/*@
  requires 0 <= x <= 10;
  requires 0 <= y <= 10;
*/
void foo(int x, int y) {
  // loop body
  /*@
  loop invariant y == x + (y - x);
  loop invariant x - y == \at(x - y, Pre);
  loop invariant (y != 0) || (x != 20);
  loop assigns x, y;
*/
while (unknown()) {
    x  = x + 10;
    y  = y + 10;
  }
  // post-condition
  if (x == 20) {
    /*@ assert y != 0; */
  }
}
