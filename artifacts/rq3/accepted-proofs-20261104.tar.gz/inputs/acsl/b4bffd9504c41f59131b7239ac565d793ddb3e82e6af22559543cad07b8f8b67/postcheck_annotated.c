int main() {
  int x = -50;
  int y = 0;

  /*@
  loop invariant 0 <= y;
  loop invariant 2 * x - y * y + y == -100;
  loop assigns x, y;
*/
while (x < 0) {
    x  = x + y;
    y  = y + 1;
  }
  // post-condition
  /*@ assert y > 0; */
}
