/*@
requires n > 0;
*/
void foo(int n) {
    int x = 1;
    int y = 0;

    /*@
  loop invariant (y == 0) || (y == n - x + 1);
  loop invariant (y == 0) || (y == n - x + 1);
  loop invariant (y == 0) || (y == n - x + 1);
  loop invariant x <= n + 1;
  loop invariant 1 <= x;
  loop invariant 0 <= y;
  loop invariant (y == n - x + 1) || (x == 1);
  loop invariant (n - x + 1 >= 0) || (y == 0);
  loop invariant (y <= n - 1) || (y == 0);
  loop assigns x, y;
*/
while (x <= n) {
        y = n - x;
        x = x +1;
    }

    //post-condition
    if (n > 0) {
      ///*@ assert y >= 0; */
      /*@ assert y < n; */
    }
}
