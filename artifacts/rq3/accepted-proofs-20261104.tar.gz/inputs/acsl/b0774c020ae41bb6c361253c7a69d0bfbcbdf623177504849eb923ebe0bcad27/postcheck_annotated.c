#include <assert.h>
int unknown1();
int unknown2();
int unknown3();
int unknown4();

void main(int flag)
{

	int x = 0;
	int y = 0;

	int j = 0;
	int i = 0;

    // invariant (j >= i)
	/*@
  loop invariant j + y + 1 + (flag ? 1 : 0) >= i + x + 1;
  loop invariant j + (flag ? 1 : 0) >= i;
  loop invariant j >= i;
  loop invariant x == y;
  loop assigns i, j, x, y;
*/
while(unknown1())
	{
	  x++;
	  y++;
	  i += x;
	  j += y;
	  if (flag)
	  	j+=1;
	} 
	/*@ assert j>=i; */
	
}
