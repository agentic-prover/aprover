/*@
requires i == 1;
requires j == 20;
*/
void foo(int i, int j) {
  // loop body
  /*@
  loop invariant i + 2*j == \at(i, Pre) + 2*\at(j, Pre);
  loop invariant 0 <= \at(i, Pre) + 2*\at(j, Pre) - i - 2*j;
  loop invariant (i + 2*j) % 3 == (\at(i, Pre) + 2*\at(j, Pre)) % 3;
  loop invariant j - i >= -3;
  loop invariant (j - i < 0) || (j >= i);
  loop assigns i, j;
*/
while (j >= i) {
    i  = i + 2;
    j  = j - 1;
  }
  // post-condition
  /*@ assert j == 13; */
}
