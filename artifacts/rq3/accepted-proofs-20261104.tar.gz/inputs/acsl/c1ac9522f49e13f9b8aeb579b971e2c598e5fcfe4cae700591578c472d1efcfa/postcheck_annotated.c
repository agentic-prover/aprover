// contract for test
/*@
  requires x >= 0;
  assigns \nothing;
  ensures \result == x;
*/

#include<limits.h>

int test(int x) {
    int a = x;
    int y = 0;

    /*@
  loop invariant 0 <= a;
  loop invariant y + a == x;
  loop assigns a, y;
*/
while(a != 0) {
        y = y + 1;
        a = a - 1;
    }
    return y;
}
    
int main() {
    int num = test(3);
    //@ assert num == 3;
    return 0;
}