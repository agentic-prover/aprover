#include <assert.h>

/*
 * "split.c" from InvGen benchmark suite
 */

void main() {
  int k = 100;
  int b;
  int i;
  int j;
  int n;
  i = j;
  // invariant (n % 2 == 1 || i == j)
  // invariant (0 <= n && n <= 2 * k)
  /*@
  loop invariant 0 <= n;
  loop invariant n <= 2 * k;
  loop invariant (n % 2 == 0) ==> (i == j);
  loop invariant (n % 2 == 1) ==> ((b == 0) ==> (i == j + 1));
  loop invariant (n % 2 == 1) ==> ((b != 0) ==> (j == i + 1));
  loop invariant (n % 2 == 1) ==> ((i == j + 1) || (j == i + 1));
  loop assigns n, b, i, j;
*/
for( n = 0 ; n < 2*k ; n++ ) {
    if(b) {
      i++;
    } else {
      j++;
    }
    b = !b;
  }
  /*@ assert i == j; */
}
