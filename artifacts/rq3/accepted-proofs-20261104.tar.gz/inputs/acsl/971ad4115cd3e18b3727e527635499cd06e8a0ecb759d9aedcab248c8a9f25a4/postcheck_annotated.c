#include <limits.h>
/*@ axiomatic AccFold_sum_sum_ax {
  logic integer AccFold_sum_sum(int *a, integer m, integer k) reads a[m .. k-1];
  axiom AccFold_sum_sum_empty: \forall int *a, integer m, k;
    m >= k ==> AccFold_sum_sum(a, m, k) == 0;
  axiom AccFold_sum_sum_step:  \forall int *a, integer m, k;
    m < k ==> AccFold_sum_sum(a, m, k) == AccFold_sum_sum(a, m, k-1) + a[k-1];
} */
// contract for sumArray
/*@
  requires n >= 0;
  requires \valid_read(a + (0 .. n-1));
  requires \forall integer k; 0 <= k <= n ==>
             INT_MIN <= AccFold_sum_sum(a, 0, k) <= INT_MAX;
  assigns \nothing;
  ensures \result == AccFold_sum_sum(a, 0, n);
*/

int sumArray(int *a, int n) {
    int p = 0, sum = 0;

    /*@
  loop invariant 0 <= p;
  loop invariant p <= n;
  loop invariant sum == AccFold_sum_sum(a, 0, p);
  loop assigns p, sum;
  loop variant n - p;
*/
while (p < n) {
        sum = sum + a[p];
        p++;
    }
    return sum;
}

// write a test
void main() {
    int arr[5] = {1, 2, 3, 4, 5};
    int sum = sumArray(arr, 5);
    //@ assert sum == 15;
}