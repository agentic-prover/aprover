/*@
requires n >= 0;
requires k >= 0;
*/
void foo(int k, int n) {
  int i = 0;
  int j = 0;
  
  /*@
  loop invariant (n+1) + (n+1)*(n+2)/2 + k > 2*n;
  loop invariant 0 <= i;
  loop invariant i <= n + 1;
  loop invariant j == i * (i + 1) / 2;
  loop assigns i, j;
*/
while (i <= n) {
    i  = i + 1;
    j  = j + i;
  }
  // post-condition
  /*@ assert i + j + k > 2*n; */
}
