
int main() {
    int x = 1;
    int y = 0;

    /*@
  loop invariant x <= 101;
  loop invariant x >= 1;
  loop invariant y >= 0;
  loop invariant y <= 99;
  loop assigns x, y;
*/
while (x <= 100) {
        y = 100 - x;
        x = x +1;
    }

    //post-condition
    ///*@ assert y >= 0; */
    /*@ assert y < 100; */
}
