/*@
requires c>0;
*/
void foo(int a, int m, int c) {
    int j = 0;
    int k = 0;

    /*@
  loop invariant 0 <= k;
  loop invariant k <= c;
  loop invariant ((c > 0) ==> (a <= m)) || (k == 0);
  loop assigns k, m;
*/
while ( k < c) {
        if(m < a) {
            m = a;
        }
        k = k + 1;
    }

    //post-condition
    if(c > 0) {
        /*@ assert a <=  m; */
    }
}