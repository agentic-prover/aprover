#include "assert.h"

/*@
requires 0 <= n && n < 2;
requires 0 <= v;
*/
int foo(int n, int v) {
  int c1 = 4000;
  int c2 = 2000;
  int c3 = 10000;
  //int n, v;
  int i, k, j;



  k = 0;
  i = 0;
  // invariant ( k >= i * c2)
  /*@
  loop invariant 0 <= i;
  loop invariant i <= n;
  loop invariant k >= i * c2;
  loop assigns i, k, v;
*/
while( i < n ) {
    i++;

    if( v == 0 )
      k += c1;
    else if( v == 1 )
      k += c2;
    else
      k += c3;
  }

  j = 0;
  // invariant (k + j >= n * c2)
  /*@
  loop invariant 0 <= j <= n;
  loop invariant k + j >= n * c2;
  loop invariant (k >= 1) || (j >= n);
  loop invariant 0 <= j <= n;
  loop invariant k + j >= n * c2;
  loop assigns j, k;
*/
while( j < n ) {
    /*@ assert k > 0; */
    j++;
    k--;
  }

  return 0;
}