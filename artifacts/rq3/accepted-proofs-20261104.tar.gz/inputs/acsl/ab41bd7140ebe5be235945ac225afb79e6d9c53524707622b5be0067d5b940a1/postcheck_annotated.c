#include <assert.h>

/*
 * "nested4.c" from InvGen benchmark suite
 */

/*@
requires l > 0;
requires n > l;
*/
void foo(int n, int l) {
  int i,k;

  

  // invariant (1 <= k && k <= n)
  /*@
  loop invariant 1 <= k;
  loop invariant k <= n;
  loop assigns k, i;
*/
for (k=1; k<n; k++){
  	// invariant (l <= i && i <= n)
    /*@
  loop invariant l <= i;
  loop invariant i <= n;
  loop assigns i;
*/
for (i=l; i<n; i++) {
    }
    // invariant (l <= i && i <= n)
    /*@
  loop invariant l <= i;
  loop invariant i <= n;
  loop assigns i;
*/
for (i=l; i<n; i++) {
      /*@ assert 1<=i; */
    }
  }

}
