int main(){
    int i=0;

    /*@
  loop invariant 0 <= i;
  loop invariant i <= 30;
  loop assigns i;
*/
while (i<30){
        ++i;
    }
    //@assert i==30;
   
}