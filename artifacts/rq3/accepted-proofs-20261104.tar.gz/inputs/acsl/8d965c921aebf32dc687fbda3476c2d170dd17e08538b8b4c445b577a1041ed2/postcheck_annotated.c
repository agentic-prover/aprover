#include <assert.h>
int unknown1();
int unknown2();
int unknown3();
int unknown4();

void foo(int n)
{
 int k=1;
 int i=1;
 int j=0;
 // invariant (i <= n && k >= i)
 /*@
  loop invariant i >= 1;
  loop invariant k >= i;
  loop assigns i, j, k;
*/
while(i < n) {
  j = 0;
  /*@
  loop invariant 0 <= j;
  loop invariant j <= i;
  loop invariant i >= 1;
  loop invariant k >= i + i * j - j * (j - 1) / 2;
  loop invariant k >= i;
  loop assigns j, k;
*/
while(j < i) {
      k += (i-j);
      j++;
  }
  i++;
 }
 /*@ assert k >= n; */
 
}
