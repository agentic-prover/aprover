#include <assert.h>

/*
  * "nested2.c" from InvGen benchmark suite
  */
/*@
requires l > 0;
*/
void foo(int l) {
  int i, k, n;
  

  // invariant (1 <= k && k <= n)
  /*@
  loop invariant 1 <= k;
  loop assigns k, i;
*/
for (k = 1; k < n; k++) {
    /*@
  loop invariant 1 <= k;
  loop invariant k <= n;
  loop invariant l <= i;
  loop assigns i;
*/
for (i = l; i < n; i++) {

    }
    // invariant (l <= i && i <= n)
    /*@
  loop invariant 1 <= k;
  loop invariant k <= n;
  loop assigns i;
*/
for (i = l; i < n; i++) {
      /*@ assert 1 <= k; */
    }
  }

}