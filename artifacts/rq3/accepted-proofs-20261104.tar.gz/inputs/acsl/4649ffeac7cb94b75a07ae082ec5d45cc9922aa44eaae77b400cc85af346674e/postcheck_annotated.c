#include<limits.h>

/*@
  assigns \nothing;
  ensures \result == p * n * r / 100;
*/
int simple(int p,int n,int r)
{
    int si;
    si = p*n*r/100;
    return si;
}
 
int main()
{
    int s = simple(10000, 3,10);
    return 0;
}