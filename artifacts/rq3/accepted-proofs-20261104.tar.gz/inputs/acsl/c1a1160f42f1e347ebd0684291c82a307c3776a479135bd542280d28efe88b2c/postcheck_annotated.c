#include "assert.h"

/*@
requires n > 0;
*/
void foo(int n) {
  //int n;
  int i = 0;
  int k = 0;
// invariant (i == k && i <= n)
  /*@
  loop invariant 0 <= i;
  loop invariant i <= n;
  loop invariant i == k;
  loop assigns i, k;
*/
while( i < n ) {
	  i++;
	  k++;
  }

  int j = 0;
  // invariant (j + k == n)
  /*@
  loop invariant 0 <= j;
  loop invariant j <= n;
  loop invariant j + k == n;
  loop assigns j, k;
*/
while( j < n ) {
    /*@ assert k > 0; */
    j++;
    k--;
  }
}