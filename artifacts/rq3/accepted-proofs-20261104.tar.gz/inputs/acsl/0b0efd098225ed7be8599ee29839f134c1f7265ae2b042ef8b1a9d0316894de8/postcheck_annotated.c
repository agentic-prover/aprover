/*@
requires a <= m;
*/
void foo(int a, int m, int c) {
    int j = 0;
    int k = 0;

    /*@
  loop invariant 0 <= k;
  loop invariant (a <= m) || (m == \at(m, Pre));
  loop assigns k, m;
*/
while (k < c) {
        if(m < a) {
            m = a;
        }
        k = k + 1;
    }

    //post-condition
    /*@ assert a <= m; */
}
