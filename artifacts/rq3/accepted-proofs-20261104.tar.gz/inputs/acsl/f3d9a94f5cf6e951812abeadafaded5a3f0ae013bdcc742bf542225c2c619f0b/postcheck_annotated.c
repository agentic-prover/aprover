
void foo(int y, int z)
{
   int x = 0;

   /*@
  loop invariant 0 <= x;
  loop invariant x <= 5;
  loop invariant (z >= y) || (z > \at(z, Pre) - 1);
  loop invariant (z >= y) || ((z <= \at(y, Pre)) && (y >= z));
  loop invariant (y >= z) || (z >= y);
  loop invariant 0 <= x;
  loop invariant x <= 5;
  loop invariant (x == 0) || (z >= y);
  loop assigns x, y;
*/
while(x < 5) {
      x += 1;
      if( z <= y) {
         y = z;
      }
   }

   //post-condition
   /*@ assert z >= y; */
}
