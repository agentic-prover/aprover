int main() {
  int x = -5000;
  int y = 0;
  
  /*@
  loop invariant y >= 0;
  loop invariant 2 * x - y * (y - 1) == -10000;
  loop assigns x, y;
*/
while ((x < 0)) {
    x  = x + y;
    y  = y + 1;
  }
  // post-condition
  /*@ assert y > 0; */
}
