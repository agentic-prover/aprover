int main() {
  int x = -50;
  int y = 0;
  
  /*@
  loop invariant 0 <= y;
  loop invariant x == -50 + y * (y - 1) / 2;
  loop invariant y <= 11;
  loop assigns x, y;
*/
while (x < 0) {
    x  = x + y;
    y  = y + 1;
  }
  // post-condition
  /*@ assert y > 0; */
}
