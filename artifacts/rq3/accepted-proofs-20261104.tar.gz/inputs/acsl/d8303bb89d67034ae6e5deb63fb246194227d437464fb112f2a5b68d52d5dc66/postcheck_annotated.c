// sum01_true-unreach-call_true-termination.c

/*@
requires 0 <= n;
requires n < 1000;
*/
int foo(int n) {
    //int n;
    
    int i=0;
    int sn=0;
    
    
    
    
    
    
    /*@
  loop invariant 1 <= i;
  loop invariant i <= n + 1;
  loop invariant sn == 2 * (i - 1);
  loop invariant (n >= 1) ==> (sn == 2 * (i - 1));
  loop invariant (n < 1) ==> ((sn == 0) && (i == 1));
  loop invariant (i == n + 1) ==> (sn == n * 2);
  loop invariant (i <= n) ==> (sn == 2 * (i - 1));
  loop invariant (sn == 0) || (sn == 2 * (i - 1));
  loop invariant (n < 1) ==> (sn == 0);
  loop invariant (n >= 1) ==> ((sn == 2 * (i - 1)) && (i >= 1) && (i <= n + 1));
  loop invariant (sn == 2 * (i - 1)) && ((i == n + 1) ==> (sn == n * 2)) && ((n < 1) ==> (sn == 0));
  loop assigns i, sn;
*/
for (i = 1; i <= n; i++) {
        sn = sn + (2);
    }
    
    /*@ assert sn == n * (2) || sn == 0; */
    
    return 0;
}
