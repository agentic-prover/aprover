
int main() {
    int x = 1;
    int y = 0;

    /*@
  loop invariant 1 <= x;
  loop invariant x <= 101;
  loop invariant y == (x == 1 ? 0 : 101 - x);
  loop assigns x, y;
*/
while (x <= 100) {
        y = 100 - x;
        x = x +1;
    }

    //post-condition
    /*@ assert y >= 0; */
    ///*@ assert y < 100; */
}
