/*@
requires size >= 1;
*/
void foo(int size) {
  int i = 1;
  int sn = 0;
  
  /*@
  loop invariant sn == i - 1;
  loop invariant 1 <= i;
  loop invariant i <= size + 1;
  loop assigns i, sn;
*/
while (i <= size) {
    i = i + 1;
    sn = sn + 1;
  }
  // post-condition
  if(sn != 0) {
    /*@ assert sn == size; */
  }
}
