/*@
requires i == 1;
requires j == 20;
*/
void foo(int i, int j) {
  // loop body
  /*@
  loop invariant i + 2*j == \at(i, Pre) + 2*\at(j, Pre);
  loop invariant 0 <= i - \at(i, Pre);
  loop invariant (i - \at(i, Pre)) % 2 == 0;
  loop invariant j == (\at(i, Pre) + 2*\at(j, Pre) - i) / 2;
  loop invariant i - 3 <= j + 1;
  loop invariant (j < i) || (j >= i - 2);
  loop invariant i + 2*j == \at(i, Pre) + 2*\at(j, Pre);
  loop invariant 0 <= i - \at(i, Pre);
  loop invariant (i - \at(i, Pre)) % 2 == 0;
  loop invariant j == (\at(i, Pre) + 2*\at(j, Pre) - i) / 2;
  loop invariant j >= i - 3;
  loop assigns i, j;
*/
while (j >= i) {
    i  = i + 2;
    j  = j - 1;
  }
  // post-condition
  /*@ assert j == 13; */
}
