/*@
requires x == y;
*/
void foo(int x, int y) {
  int lock = 1;
  
  /*@
  loop invariant (x != y) || (lock == 1);
  loop invariant x == y;
  loop assigns lock, x, y;
*/
while (x != y) {  
    if (unknown()) {
      lock = 1;
      x = y;
    } else {
      lock  = 0;
      x  = y;
      y  = y + 1; 
    }
  }
  // post-condition
  /*@ assert lock == 1; */
}
