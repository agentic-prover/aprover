int main()
{
    int x = 1;
    int m = 1;
    int n;

    /*@
  loop invariant 1 <= m;
  loop invariant (m < x) || (m == 1);
  loop invariant 1 <= x;
  loop invariant (m < n) || (m == 1);
  loop assigns m, x;
*/
while (x < n) {
        if (unknown()) {
            m = x;
        }
        x = x + 1;
    }

    //post-condition
    if(n > 1) {
       /*@ assert m < n; */
       ///*@ assert m >= 1; */
    }
}
