/*@
requires i == 1;
requires j == 20;
*/
void foo(int i, int j) {
  // loop body
  /*@
  loop invariant 2*j + i == 2*\at(j, Pre) + \at(i, Pre);
  loop invariant j >= i - 3;
  loop assigns i, j;
*/
while (j >= i) {
    i  = i + 2;
    j  = j - 1;
  }
  // post-condition
  /*@ assert j == 13; */
}
