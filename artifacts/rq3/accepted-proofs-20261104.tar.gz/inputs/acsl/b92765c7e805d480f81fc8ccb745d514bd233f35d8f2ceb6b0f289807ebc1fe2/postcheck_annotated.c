#include <assert.h>
int unknown1();
int unknown2();
int unknown3();
int unknown4();

void foo(int n)
{
  int x=0;
  int y=0;
  int i=0;
  
  // invariant (i % 2 == 1 || x == 2 * y)
  /*@
  loop invariant 0 <= i;
  loop invariant ((i % 2 == 1) || (x == 2 * y));
  loop invariant x == i;
  loop invariant y == i / 2;
  loop assigns i, x, y;
*/
while(i<n) {
    i++;
    x++;
    if(i%2 == 0) y++;
  }
  
  if(i%2 == 0) {
    /*@ assert x==2*y; */
  }
}

