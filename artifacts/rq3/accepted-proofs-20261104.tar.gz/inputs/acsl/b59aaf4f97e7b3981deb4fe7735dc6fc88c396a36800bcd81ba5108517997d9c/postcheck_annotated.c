#include <limits.h>
#include "assert.h"

int unknown1();

/*@
requires n < INT_MAX;
*/
int foo(int k, int n) {
    int i,j;
    //int k,n;
n = __VERIFIER_nondet_int();
    
    if( k == n) {
    }
    else {
        goto END;
    }

    /*@
  loop invariant 0 <= i;
  loop invariant k == n;
  loop assigns i, j, k;
*/
for (i = 0; i < n; i++) {
        // invariant (k == n)
        /*@
  loop invariant 2*i <= j;
  loop invariant k == n;
  loop assigns j, k;
*/
for (j= 2 * i; j < n; j++) {
            if(unknown1()) {
                /*@
  loop invariant k >= j;
  loop invariant j >= 2*i;
  loop invariant k <= n;
  loop invariant k >= 2*i;
  loop assigns k;
*/
for (k = j; k < n; k++) {
                    /*@ assert k >= 2*i; */
                }
            }
            else {
                /*@ assert k >= n; */
                /*@ assert k <= n; */
            }
        }
    }
END:
    return 0;
}