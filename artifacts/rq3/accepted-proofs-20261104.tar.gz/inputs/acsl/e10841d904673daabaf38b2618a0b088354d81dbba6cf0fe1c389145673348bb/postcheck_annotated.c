int main()
{
    int x = 1;
    int m = 1;
    int n;

    /*@
  loop invariant 1 <= m;
  loop invariant 1 <= x;
  loop invariant (m < x) || (m == 1);
  loop invariant (m < n) || (n <= 1);
  loop assigns m, x;
*/
while (x < n) {
        if (unknown()) {
            m = x;
        }
        x = x + 1;
    }

    //post-condition
    if(n > 1) {
       /*@ assert m < n; */
       ///*@ assert m >= 1; */
    }
}
