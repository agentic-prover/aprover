// contract for arraySearch
/*@
  requires n >= 0;
  requires \valid_read(a + (0 .. n-1));
  assigns \nothing;
  ensures (\exists integer k; 0 <= k < n && (a[k] == x)) ==> \result == 1;
  ensures \result == 0 ==> (\forall integer k; 0 <= k < n ==> a[k] != x);
*/

int arraySearch(int *a, int x, int n) {
    int p = 0;

    /*@
  loop invariant 0 <= p <= n;
  loop invariant \forall integer k; (0 <= k < p) ==> (a[k] != x);
  loop assigns p;
*/
while (p < n) {
        if (a[p] == x) {
            return 1;
        }
        p++;
    }
    return 0;
}

// write a test
void main() {
    int arr[5] = {1, 2, 3, 4, 5};
    int sum = arraySearch(arr, 3, 5);
    //@ assert sum == 1;
}