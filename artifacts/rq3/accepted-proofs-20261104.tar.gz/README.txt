Archived BMC-Agent RQ3 accepted proof inputs

This bundle contains revalidated source inputs and flags, with hashes and original
trial coverage. It makes zero model calls. It does not rerun generation or verify
the original failed trials, and must not be presented as fresh generation scores.
Original benchmark copyright/license comments remain in the source files.

Extract to any directory. From the reproduction checkout, run:
python experiments/paper_reproduction/replay_verifiers.py jml \
  --manifest /path/to/bundle/jml_manifest.json --tool /path/to/openjml \
  --output artifacts/bundle-replay/jml --workers 4 --fail-fast --execute
python experiments/paper_reproduction/replay_verifiers.py acsl \
  --manifest /path/to/bundle/acsl_manifest.json \
  --tool experiments/paper_reproduction/tools/frama-c \
  --output artifacts/bundle-replay/acsl --workers 4 --fail-fast --execute

Omit --execute to inspect only the selected-input plan.
